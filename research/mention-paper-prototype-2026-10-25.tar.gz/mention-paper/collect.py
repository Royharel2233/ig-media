"""Prospective snapshot collector. Appends immutable rows to data/snapshots/YYYY-MM-DD.jsonl.
Only OPEN markets are recorded (closed=false at fetch time), so a row can never contain a price
that already reflects the outcome. Each row stores fetched_at (UTC) - scoring uses only rows
fetched before a pre-declared cutoff. Run: python3 collect.py"""
import json, os, sys
from common import *

def gamma_events():
    out, off = [], 0
    while True:
        d = get_json(f"{GAMMA}/events?tag_slug=mention-markets&closed=false&limit=100&offset={off}")
        if not d:
            break
        out += d
        if len(d) < 100:
            break
        off += 100
    return out

def main():
    t = now_utc(); fetched = iso(t)
    rows = []
    for ev in gamma_events():
        slug = ev["slug"]
        end = ev.get("endDate")
        if end and parse_iso(end) < t:
            continue  # past end, awaiting resolution: skip, not a forecast
        br = get_json(f"{PARROT}/brief?event=p:{slug}&limit=0&format=json")
        prow = {}
        pmeta = {}
        if br:
            pmeta = {"as_of": br["meta"].get("as_of"), "coverage": (br["meta"].get("coverage") or {}).get("line")}
            for r in table(br):
                prow[norm(r["w"])] = r
        for m in ev["markets"]:
            if m.get("closed"):
                continue
            title = m.get("groupItemTitle") or ""
            if title.startswith("-No Qualifying"):
                continue
            pr = prow.get(norm(title))
            rows.append({
                "fetched_at": fetched, "event_slug": slug, "event_title": ev.get("title"),
                "event_end": end, "market_id": m.get("id"), "condition_id": m.get("conditionId"),
                "word": title, "bid": f(m.get("bestBid")), "ask": f(m.get("bestAsk")),
                "last": f(m.get("lastTradePrice")), "volume": f(m.get("volumeNum")),
                "parrot_p": f(pr.get("p")) if pr else None,
                "parrot_p_src": pr.get("p_src") if pr else None,
                "parrot_n": pr.get("n") if pr else None, "parrot_y": pr.get("y") if pr else None,
                "parrot_as_of": pmeta.get("as_of"),
            })
    os.makedirs(f"{DATA}/snapshots", exist_ok=True)
    path = f"{DATA}/snapshots/{t.strftime('%Y-%m-%d')}.jsonl"
    with open(path, "a") as fh:
        for r in rows:
            fh.write(json.dumps(r, sort_keys=True) + "\n")
    ev_n = len({r["event_slug"] for r in rows})
    print(f"{fetched} wrote {len(rows)} market rows across {ev_n} events -> {path}")

if __name__ == "__main__":
    main()
