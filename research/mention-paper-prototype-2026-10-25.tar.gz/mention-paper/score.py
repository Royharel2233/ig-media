"""Prospective scoring. For each resolved market and each pre-declared cutoff (hours before event_end),
use ONLY the last snapshot with fetched_at <= event_end - cutoff. Resolution outcomes come from
Polymarket gamma (umaResolutionStatus == resolved, outcomePrices exactly 1/0); voids/50-50 are excluded.
Predictors: market mid (bid/ask midpoint; falls back to last trade), parrot p (base rate, NOT a forecast
from news), blend 0.7*mid+0.3*parrot (the MixMCP weights but with a base rate in place of an LLM -
this is NOT MixMCP). Paper trade: buy YES at ask or NO at (1-bid) when |p_model - price| >= EDGE,
one share, hold to resolution, taker fee = 0.04*p*(1-p) per share (Polymarket mentions rule as
reported in the feasibility doc). Nothing here places orders.
Run: python3 score.py [--cutoffs 24 6] [--edge 0.10]"""
import glob, json, math, argparse, collections
from common import *

def load_snaps():
    rows = []
    for p in sorted(glob.glob(f"{DATA}/snapshots/*.jsonl")):
        rows += [json.loads(l) for l in open(p) if l.strip()]
    return rows

def outcomes(slugs):
    cache_path = f"{DATA}/outcomes.json"
    cache = json.load(open(cache_path)) if os.path.exists(cache_path) else {}
    for s in slugs:
        d = get_json(f"{GAMMA}/events?slug={s}")
        if not d:
            continue
        for m in d[0]["markets"]:
            if m.get("closed") and m.get("umaResolutionStatus") == "resolved":
                try:
                    pr = [float(x) for x in json.loads(m["outcomePrices"])]
                except Exception:
                    continue
                if pr[0] == 1.0 and pr[1] == 0.0: cache[m["id"]] = 1
                elif pr[0] == 0.0 and pr[1] == 1.0: cache[m["id"]] = 0
                else: cache[m["id"]] = None  # void / split: excluded
    json.dump(cache, open(cache_path, "w"))
    return cache

def mid(r):
    b, a = r.get("bid"), r.get("ask")
    if b is not None and a is not None: return (a + b) / 2
    return r.get("last")

def fee(p): return 0.04 * p * (1 - p)

def metrics(pairs):
    n = len(pairs)
    if not n: return None
    eps = 1e-3
    br = sum((p - y) ** 2 for p, y in pairs) / n
    ll = -sum(y * math.log(min(max(p, eps), 1 - eps)) + (1 - y) * math.log(1 - min(max(p, eps), 1 - eps)) for p, y in pairs) / n
    return {"n": n, "brier": round(br, 4), "logloss": round(ll, 4)}

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--cutoffs", type=float, nargs="+", default=[24, 6])
    ap.add_argument("--edge", type=float, default=0.10)
    a = ap.parse_args()
    snaps = load_snaps()
    by_m = collections.defaultdict(list)
    for r in snaps: by_m[r["market_id"]].append(r)
    res = outcomes(sorted({r["event_slug"] for r in snaps}))
    report = {"n_snapshot_rows": len(snaps), "n_markets_seen": len(by_m),
              "n_resolved": sum(1 for m in by_m if res.get(m) in (0, 1)), "cutoffs_h": a.cutoffs, "edge": a.edge, "by_cutoff": {}}
    for c in a.cutoffs:
        preds = {"market_mid": [], "parrot_p": [], "blend_70_30": []}
        common_set = []; trades = []
        for m, rows in by_m.items():
            y = res.get(m)
            if y not in (0, 1): continue
            end = parse_iso(rows[0]["event_end"])
            lim = end - dt.timedelta(hours=c)
            ok = [r for r in rows if parse_iso(r["fetched_at"]) <= lim]
            if not ok: continue
            r = max(ok, key=lambda r: r["fetched_at"])
            mp, pp = mid(r), r.get("parrot_p")
            if mp is None or pp is None: continue  # score all predictors on the SAME markets
            common_set.append((mp, pp, 0.7 * mp + 0.3 * pp, y))
            if r.get("bid") is not None and r.get("ask") is not None:
                model = 0.7 * mp + 0.3 * pp  # model price for the trade rule
                if model - r["ask"] >= a.edge:
                    trades.append(("YES", r["ask"], y, r["volume"]))
                elif (1 - model) - (1 - r["bid"]) >= a.edge:
                    trades.append(("NO", 1 - r["bid"], 1 - y, r["volume"]))
        for i, k in enumerate(preds): preds[k] = [(t[i], t[3]) for t in common_set]
        pnl = [(1 - px) - fee(px) if won else -px - fee(px) for _, px, won, _ in trades]
        report["by_cutoff"][str(c)] = {
            "scored_markets": len(common_set),
            "metrics": {k: metrics(v) for k, v in preds.items()},
            "paper_trades": {"n": len(trades), "pnl_per_share_total": round(sum(pnl), 3) if pnl else None,
                              "note": "1 share each at the quoted ask, ignores depth/slippage beyond best quote; tiny n is noise"},
        }
    os.makedirs("results", exist_ok=True)
    json.dump(report, open("results/prospective_report.json", "w"), indent=1)
    print(json.dumps(report, indent=1))
    if report["n_resolved"] < 100:
        print("\nWARNING: fewer than ~100 resolved markets scored; differences are not distinguishable from luck.")

if __name__ == "__main__":
    main()
