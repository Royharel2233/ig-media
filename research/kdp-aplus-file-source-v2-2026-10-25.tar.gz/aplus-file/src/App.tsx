import React from 'react';
import { Callout, Caption, Closing, FileCard, Group, Header, NumberedList, Paragraph, Photos, Row, Rows } from '@instinct/files';
import './style.css';
import bannerC from './photos/banner-c.jpg';
import bannerA from './photos/banner-a.jpg';
import bannerB from './photos/banner-b.jpg';

export function App() {
    return <FileCard>
        <Header
            title="A+ Content ו־Author Central - מוכן להעלאה"
            fact="25 באוקטובר 2026"
            intro="כל הטקסטים והבאנרים לשלושת הספרים, מוכנים להעתקה והדבקה ב־KDP. עבודה חד־פעמית של רבע שעה בערך. הבאנרים (970x600, הגודל הסטנדרטי של מודול הכותרת) מצורפים כאן בתמונות, וגם בקבצים נפרדים שקיבלת בצ'אט."
        />
        <Photos label="באנר חג המולד (banner-c)" items={[{ src: bannerC, alt: 'באנר ספר חג המולד' }]} />
        <Photos label="באנר גופן גדול (banner-a)" items={[{ src: bannerA, alt: 'באנר ספר הגופן הגדול' }]} />
        <Photos label="באנר קלקודוקו (banner-b)" items={[{ src: bannerB, alt: 'באנר ספר הקלקודוקו' }]} />

        <Group label="איך מעלים A+ Content" heading>
            <NumberedList items={[
                'KDP > Bookshelf > ליד הספר: Marketing > A+ Content.',
                'בחר את המודולים הסטנדרטיים: Image Header למודול 1, ומודול תמונה עם נקודות (Single Image & Specs או הכי קרוב אליו) למודול 2.',
                'מודול 1: העלה את הבאנר של הספר והדבק את הכותרת והטקסט מלמטה.',
                'מודול 2: העלה את כריכת הספר (אותה כריכה מהעלאה המקורית) והדבק את הנקודות.',
                'שמור ושלח. אמזון בודקת את התוכן לפני שהוא עולה, בדרך כלל כמה ימים.',
            ]} />
            <Callout title="שים לב" tone="neutral">שמות המודולים המדויקים והמדיניות העדכנית של KDP לא אומתו מחדש היום. אם שם מודול שונה, בחר את הכי קרוב. הטקסטים שמרניים בכוונה: רק מה שמופיע על הכריכות עצמן, בלי טענות על תהליך האימות או על גודל הגופן בפנים.</Callout>
        </Group>

        <Group label="ספר חג המולד (Christmas Activity Book)" heading>
            <Rows>
                <Row number={1} name="מודול 1 - כותרת" detail="A Screen-Free Christmas Activity Book" />
                <Row number={2} name="מודול 1 - טקסט" detail="46 festive activities for ages 4-8: mazes, word searches, dot-to-dot and coloring pages." />
                <Row number={3} name="מודול 2 - נקודות" detail="Ages 4-8 / 46 festive activities / Mazes, word searches, dot-to-dot, coloring" />
                <Row number={4} name="טקסט חלופי לתמונה (alt)" detail="Cover of the Christmas Activity Book for Kids: 46 festive activities, ages 4-8." />
                <Row number={5} name="משפט שיווקי אופציונלי" detail="The stocking stuffer that keeps little elves busy all December - at grandma's house, on holiday flights, and on snowy afternoons." />
            </Rows>
        </Group>

        <Group label="ספר הגופן הגדול (Large Print, Seniors)" heading>
            <Rows>
                <Row number={1} name="מודול 1 - כותרת" detail="A Gift for Puzzle Lovers" />
                <Row number={2} name="מודול 1 - טקסט" detail="90 easy puzzles, one per page." />
                <Row number={3} name="מודול 2 - נקודות" detail="90 easy puzzles / One puzzle per page" />
                <Row number={4} name="טקסט חלופי לתמונה (alt)" detail="Cover of the Large Print Puzzle Book for Seniors: 90 easy puzzles." />
                <Row number={5} name="משפט שיווקי אופציונלי" detail="A thoughtful gift for a parent or grandparent who loves puzzles." />
            </Rows>
        </Group>

        <Group label="ספר הקלקודוקו (Calcudoku Vol. 1)" heading>
            <Rows>
                <Row number={1} name="מודול 1 - כותרת" detail="Sudoku's Smarter Cousin" />
                <Row number={2} name="מודול 1 - טקסט" detail="150 math logic puzzles for adults, from easy to hard. One puzzle per page." />
                <Row number={3} name="מודול 2 - נקודות" detail="150 puzzles / Easy to hard / One puzzle per page" />
                <Row number={4} name="טקסט חלופי לתמונה (alt)" detail="Cover of Calcudoku Puzzles for Adults Volume 1: 150 puzzles from easy to hard." />
                <Row number={5} name="משפט שיווקי אופציונלי" detail="Already love Sudoku? Calcudoku adds an arithmetic twist." />
            </Rows>
        </Group>

        <Group label="Author Central - ביוגרפיה של Walter Hayes" heading>
            <Paragraph>כתובת: author.amazon.com. נכנסים עם אותו חשבון אמזון של KDP, מאמתים את שם המחבר Walter Hayes, ובשדה הביוגרפיה מדביקים:</Paragraph>
            <Rows>
                <Row number={1} name="Biography" detail="Walter Hayes writes puzzle books for people who want their downtime to feel well spent. His Clear Mind Puzzles series includes large-print puzzles for seniors, calcudoku for adults, and seasonal activity books for kids." />
            </Rows>
            <Paragraph>אחרי שהפרופיל פעיל, אפשר לשייך אליו את שלושת הספרים, ואז כולם יופיעו בדף מחבר אחד שמחזק את המותג.</Paragraph>
        </Group>

        <Closing>אם משהו נראה אחרת במסך שלך, שלח צילום ואכוון מדויק.</Closing>
    </FileCard>;
}
