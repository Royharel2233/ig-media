from pathlib import Path
import json, math, textwrap
from reportlab.pdfgen import canvas
from reportlab.lib.colors import HexColor, Color, black, white
from reportlab.lib.pagesizes import A4, letter
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import Paragraph
from reportlab.lib.styles import ParagraphStyle

ROOT=Path(__file__).resolve().parents[1]
DATA=json.loads((ROOT/'source/content.json').read_text())
for n,f in [('Body','NotoSans-Regular.ttf'),('Bold','NotoSans-Bold.ttf'),('Display','NotoSerif-Regular.ttf')]:
    pdfmetrics.registerFont(TTFont(n,'/usr/share/fonts/truetype/noto/'+f))
INK=HexColor('#242d35'); TEAL=HexColor('#27655d'); PALE=HexColor('#f1f6f4'); GRAY=HexColor('#58636b'); GOLD=HexColor('#b78632')
C=None; W=H=0; X=0; WIDTH=520; PAGE=0; DOC=''

def text(x,t,s,size=11,font='Body',color=INK):
    C.setFillColor(color);C.setFont(font,size);C.drawString(X+x,H-t-size*.82,s)
def right(x,t,s,size=10,font='Body',color=GRAY):
    C.setFillColor(color);C.setFont(font,size);C.drawRightString(X+x,H-t-size*.82,s)
def para(x,t,s,width=520,size=11.5,leading=16,color=INK,font='Body'):
    sty=ParagraphStyle('p',fontName=font,fontSize=size,leading=leading,textColor=color,spaceAfter=0)
    p=Paragraph(s,sty);pw,ph=p.wrap(width,1000);p.drawOn(C,X+x,H-t-ph);return ph

def line(x,t,x2,t2,color=GRAY,width=.7):
    C.setStrokeColor(color);C.setLineWidth(width);C.line(X+x,H-t,X+x2,H-t2)
def box(x,t,w,h,fill=None,stroke=TEAL,r=0):
    C.setStrokeColor(stroke);C.setLineWidth(.7)
    C.setFillColor(fill or white)
    C.roundRect(X+x,H-t-h,w,h,r,stroke=1,fill=bool(fill))
def star(x,t,r=10,color=GOLD):
    p=C.beginPath()
    for i in range(10):
        a=math.pi/2+i*math.pi/5; rr=r if i%2==0 else r*.43
        xx=X+x+math.cos(a)*rr; yy=H-t+math.sin(a)*rr
        if i==0:p.moveTo(xx,yy)
        else:p.lineTo(xx,yy)
    p.close();C.setStrokeColor(color);C.setLineWidth(1);C.drawPath(p,fill=0,stroke=1)
def envelope(x,t,w=80,h=50):
    box(x,t,w,h,None,TEAL);line(x,t,x+w/2,t+h*.56,TEAL);line(x+w,t,x+w/2,t+h*.56,TEAL)
    line(x,t+h,x+w*.33,t+h*.43,TEAL);line(x+w,t+h,x+w*.67,t+h*.43,TEAL)
def begin(path,size,doc):
    global C,W,H,X,PAGE,DOC
    W,H=size;X=(W-WIDTH)/2;PAGE=0;DOC=doc
    C=canvas.Canvas(str(path),pagesize=size);C.setTitle(DATA['title']+' | '+doc);C.setAuthor(DATA['brand']);C.setSubject('Original cooperative printable Christmas puzzle game. Version 0.9.')
def page(label,title,sub=None):
    global PAGE
    PAGE+=1
    text(0,27,'LETTERLIGHT DISPATCH',9,'Bold',TEAL);right(520,27,label.upper(),8.8,'Bold')
    line(0,46,520,46,TEAL,1)
    text(0,63,title,25,'Display')
    if sub:para(0,101,sub,size=11,leading=15,color=GRAY)
def footer():
    line(0,H-35,520,H-35,HexColor('#cbd5d1'),.5)
    text(0,H-24,'The Christmas Signal  /  v0.9  /  Personal play',7.8,color=GRAY)
    right(520,H-24,str(PAGE),8)
    C.showPage()
def panel(t,job,title,partner):
    box(0,t,520,174,None,HexColor('#b3c6bf'))
    text(12,t+10,f'JOB {job}  /  {title}',13,'Bold',TEAL)
    right(508,t+11,f'WITH {partner}',9,'Bold',GRAY)
    return t+36

def game(path,size):
    begin(path,size,'Player game')
    page('Start here','The Christmas Signal','A cooperative paper escape adventure. No cutting. No locks. No screens required.')
    # Original emblem and starfield, intentionally low ink.
    envelope(211,144,98,60)
    # Original low-ink town skyline, drawn as vectors.
    for xx,hh in [(15,28),(63,43),(111,33),(364,35),(413,48),(462,28)]:
        box(xx,201-hh,39,hh,None,TEAL)
        line(xx,201-hh,xx+19.5,187-hh,TEAL)
        line(xx+19.5,187-hh,xx+39,201-hh,TEAL)
        box(xx+15,186,9,15,None,TEAL)
        for wx in [7,25]:box(xx+wx,211-hh,6,7,None,TEAL)
    line(0,208,520,208,TEAL)
    for x,t,r in [(165,153,10),(352,143,7),(184,220,6),(330,220,11)]:star(x,t,r)
    text(0,244,'One last letter. Four pairs of hands.',22,'Display')
    para(0,284,'On Christmas Eve, the Letterlight post office still has one letter to deliver. A storm has scrambled its route, timetable and final message. The lantern on the tower has gone dark. Before the village sits down to supper, your crew must send one last signal.',size=12,leading=18)
    box(0,375,520,82,PALE)
    text(14,388,'WHAT YOU NEED',9,'Bold',TEAL)
    para(14,408,'Print game pages 1-7, single-sided. Use A4 or US Letter, matching your PDF. Ordinary paper and pencils are enough. Color is optional. Page 8 is an optional celebration sheet.',width=490,size=11,leading=16)
    para(0,476,'<b>Share the clues, share the discoveries.</b> Best around one table with four players. Two to six can play by sharing or combining roles. Designed for ages 8+ with adult reading support; younger players may need help. Experienced adult puzzlers should expect a light challenge.',size=11.5,leading=17)
    para(0,567,'<b>Print setup:</b> Put page 2 in the center. Give pages 3-6 to four roles (A-D). Keep page 7 face down until all six jobs are finished. Keep the separate Help &amp; Answers PDF closed unless needed. No one has to read the solutions to set up.',size=11.5,leading=17)
    para(0,654,'Play at your own pace. Never lock anyone in a room, hide clues near hazards, or require a real flame. This is a tabletop puzzle adventure, not a physical escape.',size=10,leading=14,color=GRAY)
    footer()

    page('Mission ledger','The last dispatch','Read this aloud together. Keep this page in the middle of the table.')
    para(0,144,'Postmaster Rowan left a note:<br/><br/>"The last letter is for Mara, our tower keeper. She has kept the village lantern lit every Christmas, but tonight she is alone. Repair the six dispatch jobs to discover the missing word in her letter. Every pair of roles has something the other needs. Nobody carries the whole answer."',size=12,leading=18)
    text(0,284,'How the crew works',17,'Display')
    para(0,317,'1. Solve jobs 1 and 2, then 3 and 4, then 5 and 6.<br/>2. Find the matching job number on the two named role sheets. Both halves matter.<br/>3. Explain your clue before showing your page. Then compare freely if that helps.<br/>4. Give a different player the pencil for each job. Write each four-letter answer below.<br/>5. Once all six are done, turn over page 7 and solve the final dispatch.',size=11.5,leading=18)
    rows=[('ROUND 1','1  Find the route','A + B'),('','2  Restore the timetable','C + D'),('ROUND 2','3  Balance the mail','A + C'),('','4  Repair the signal','B + D'),('ROUND 3','5  Deliver the parcels','A + D'),('','6  Reconnect the lanterns','B + C')]
    y=435
    for rd,name,pair in rows:
        if rd:text(0,y+9,rd,8.4,'Bold',TEAL)
        text(88,y+8,name,10.2,'Bold');text(333,y+8,pair,10)
        for j in range(4):box(396+j*29,y,25,27,None,GRAY)
        y+=39
    para(0,685,'Two players: take two role sheets each and work together. Five or six: share roles. Reading, pointing and checking all count. No timer or penalty for hints.',size=10,leading=14,color=GRAY)
    footer()

    page('Role A','The route keeper','You hold the map, the parcel balances and the delivery ledger. Your partners hold the rules.')
    y=panel(141,1,'Find the route','B');
    text(14,y,'Map: north is up. Columns A-D; rows 1-4.',10.5)
    gx=178; gy=y+25;cell=25
    for j,k in enumerate('ABCD'):text(gx+j*cell+8,gy-15,k,9,'Bold')
    for i,row in enumerate(DATA['grid']):
        text(gx-15,gy+i*cell+7,str(i+1),9,'Bold')
        for j,k in enumerate(row):
            box(gx+j*cell,gy+i*cell,cell,cell,None,GRAY)
            text(gx+j*cell+8,gy+i*cell+5,k,12,'Bold')
    para(302,y+36,'The depot is A4.<br/>Start on its D.<br/>Do not record D.<br/>B holds the route.',width=200,size=10.5,leading=16)
    y=panel(328,3,'Balance the mail','C')
    para(14,y,'Each symbol always has the same whole-number weight. C has the label key and reading order.',width=490,size=10.5,leading=15)
    equations=['MITTEN + BELL = 9','BELL + STAR = 7','STAR + MITTEN = 8','ENVELOPE + STAR = 5']
    for i,eq in enumerate(equations):
        col=i%2;row=i//2;box(14+col*248,y+40+row*40,240,33,PALE)
        text(24+col*248,y+50+row*40,eq,10.5,'Bold')
    y=panel(515,5,'Deliver the parcels','D')
    para(14,y,'Three residents. Three homes. Three gifts. Each person has exactly one home and one gift; nothing repeats. D holds four witness clues.',width=490,size=10.5,leading=15)
    text(14,y+48,'Residents:  Ari  /  Bea  /  Cal',11,'Bold')
    text(14,y+72,'Homes:  Bakery  /  Orchard  /  Tower',11,'Bold')
    text(14,y+96,'Gifts:  STAR  /  BELL  /  DRUM',11,'Bold')
    footer()

    page('Role B','The signal keeper','You hold the route slip, the received telegram and six lantern panels. Do not solve alone.')
    y=panel(141,1,'Find the route','A')
    para(14,y,'Ask A to begin at the depot (A4). Move this many squares, not counting the square you leave. Record only the letter on each landing square.',width=490,size=10.5,leading=15)
    steps=['NORTH 2','EAST 2','SOUTH 1','WEST 1']
    for i,s in enumerate(steps):box(14+i*125,y+62,116,48,PALE);text(24+i*125,y+78,s,10.5,'Bold')
    y=panel(328,4,'Repair the signal','D')
    text(14,y,'The receiver printed this four-letter telegram:',10.5)
    for i,k in enumerate('UGJH'):box(130+i*63,y+30,54,48,None,TEAL);text(146+i*63,y+39,k,27,'Bold')
    para(14,y+94,'D has the repair procedure. Use the alphabet, not a keyboard. Write the repaired word on the mission ledger.',width=490,size=10.5,leading=15)
    y=panel(515,6,'Reconnect the lanterns','C')
    text(14,y,'Each panel has an entry, a letter and an exit.',10.5)
    for i,(num,left,rr,k) in enumerate(DATA['panels']):
        col=i%2;row=i//2;xx=14+col*250;tt=y+25+row*30
        box(xx,tt,241,25,None,GRAY)
        text(xx+6,tt+7,str(num),9,'Bold',TEAL);text(xx+24,tt+7,left,8.5)
        text(xx+98,tt+5,k,12,'Bold');text(xx+126,tt+7,'>',9);text(xx+145,tt+7,rr,8.5)
    footer()

    page('Role C','The parcel keeper','You hold the timetable tickets, the weight key and the lantern assembly rule.')
    y=panel(141,2,'Restore the timetable','D')
    para(14,y,'Four couriers leave at four consecutive slots: 19:00, 19:10, 19:20 and 19:30. Put their ticket letters in departure order. D has the scheduling clues.',width=490,size=10.5,leading=15)
    for i,(animal,k) in enumerate([('HARE','O'),('OWL','W'),('ROBIN','S'),('FOX','N')]):
        xx=14+i*125;box(xx,y+66,116,45,PALE);text(xx+9,y+74,animal,9,'Bold');text(xx+85,y+75,k,20,'Bold')
    y=panel(328,3,'Balance the mail','A')
    para(14,y,'A has four balanced equations. Work out the weight of each item. Then convert weights to letters with this key.',width=490,size=10.5,leading=15)
    for i,(v,k) in enumerate([(1,'R'),(2,'E'),(3,'V'),(4,'O'),(5,'D'),(6,'A')]):
        xx=14+i*83;box(xx,y+39,75,42,PALE);text(xx+8,y+49,str(v),12,'Bold');text(xx+43,y+49,k,12,'Bold')
    text(14,y+96,'Read: MITTEN, BELL, STAR, ENVELOPE.',11,'Bold')
    y=panel(515,6,'Reconnect the lanterns','B')
    para(14,y,'Reconnect the tower lanterns without cutting anything.<br/><br/>Choose exactly FOUR DIFFERENT panels from B. Start with entry START. Match each exit label to the next entry label. Finish with exit END. Read the four large letters in panel order.',width=490,size=10.5,leading=15)
    text(14,y+110,'Panel order:  ____  >  ____  >  ____  >  ____',11,'Bold')
    footer()

    page('Role D','The story keeper','You hold the scheduling rules, the receiver manual and four witness clues.')
    y=panel(141,2,'Restore the timetable','C')
    para(14,y,'Read these clues to C:<br/><br/>• Owl leaves in the last slot.<br/>• Robin leaves exactly one slot before Fox.<br/>• Hare leaves exactly one slot after Fox.<br/><br/>No courier shares a departure slot.',width=490,size=11,leading=16)
    y=panel(328,4,'Repair the signal','B')
    para(14,y,'Receiver repair manual:<br/><br/>1. Reverse the order of the four received letters.<br/>2. Move EACH letter one step BACK in the alphabet.<br/>3. Read the repaired word from left to right.',width=490,size=11,leading=17)
    text(14,y+102,'Example: BA -> AB -> ZA  (A wraps back to Z).',10,'Bold')
    y=panel(515,5,'Deliver the parcels','A')
    para(14,y,'The four witness clues:<br/><br/>• Ari lives at the Bakery.<br/>• The Tower resident receives the BELL.<br/>• Bea receives the DRUM.<br/>• Bea does not live at the Tower.',width=490,size=11,leading=16)
    text(14,y+116,'Which gift is delivered to the BAKERY?',11,'Bold')
    footer()

    page('Final dispatch','Complete the letter','Turn this page over only after all six jobs are finished. Everyone solves this last step together.')
    para(0,144,'The tower lantern is ready. The last instruction on Mara\'s letter is missing. The old postmaster used a stamp code: each dispatch answer contributes one letter. Count from 1 at the left of each answer.',size=12,leading=18)
    rows=[('1 / ROUTE','2nd'),('2 / TIMETABLE','2nd'),('3 / MAIL','3rd'),('4 / SIGNAL','2nd'),('5 / PARCELS','2nd'),('6 / LANTERNS','3rd')]
    y=233
    for i,(a,b) in enumerate(rows):
        text(12,y+9,a,10.5,'Bold',TEAL);text(199,y+9,'Take the '+b+' letter',10.5)
        box(416,y,45,32,None,TEAL);y+=44
    para(0,515,'Read the six extracted letters from top to bottom. They form one English word. This is the command that completes the last dispatch:',size=11.5,leading=17)
    box(0,570,520,78,PALE)
    para(16,585,'FINAL SIGNAL<br/>_ _ _ _ _ _',width=490,size=15,leading=24,font='Display')
    para(0,670,'When your word fits, open Help &amp; Answers at "The ending" to read Mara\'s reply. If stuck, use the progressive hints first. Hints are part of play, not a failure.',size=10.5,leading=15,color=GRAY)
    footer()

    page('Optional celebration','We sent the last signal','A keepsake for your crew. This page is optional, not another puzzle.')
    envelope(199,154,122,76)
    for x,t in [(165,178),(350,179),(182,251),(336,250)]:star(x,t,10)
    text(0,296,'The Letterlight Christmas Crew',23,'Display')
    text(0,350,'Crew name:',12,'Bold');line(90,369,520,369)
    text(0,398,'Our best teamwork moment:',12,'Bold');line(0,440,520,440);line(0,476,520,476)
    text(0,507,'Date:',12,'Bold');line(49,525,227,525)
    text(269,507,'Hints we welcomed:',12,'Bold');line(404,525,520,525)
    para(0,570,'Optional: photograph this sheet, not the puzzle answers. No faces or children\'s names are needed. Share the memory only if everyone involved is comfortable.',size=11,leading=16,color=GRAY)
    para(0,653,'Keep the lantern going: write a kind invitation of your own. Who could use one more place at the table?',size=12,leading=18,font='Display')
    footer();C.save()

HINTS=[
 ('1 / Route','A\'s grid is a map. Each instruction starts where the last one ended.','Your first landing square is A2. Read its letter, then continue from there.','The landing squares are A2, C2, C3, B3. Copy their letters.'),
 ('2 / Timetable','Treat each slot as one step. Robin, Fox and Hare must be together.','Robin comes just before Fox; Hare comes just after Fox. Owl is last.','The order is Robin, Fox, Hare, Owl. Read C\'s ticket letters in that order.'),
 ('3 / Mail','The same item has the same weight in every equation.','Try adding the first three equations: twice the total of Mitten, Bell and Star is 24.','Mitten=5, Bell=4, Star=3. Envelope=2. Use C\'s key in the printed item order.'),
 ('4 / Signal','Follow both repair steps in order. Don\'t change the letters before reversing.','UGJH becomes HJGU when reversed.','Move H, J, G, U each one step back. The word begins G.'),
 ('5 / Parcels','Use the fact that no home and no gift can repeat.','Ari is at the Bakery and Bea is not at the Tower, so Cal must be at the Tower.','Cal has the Bell. Bea has the Drum. Ari gets the remaining gift.'),
 ('6 / Lanterns','Do not cut the panels. Write their numbers in a chain.','START forces panel 4. At DOT, one choice wastes two panels on a loop.','The four-panel chain is 4 > 1 > 6 > 2. Read their large letters.'),
 ('7 / Final dispatch','Use the answer words, not the job names. Count letters starting at 1.','PINE contributes I. SNOW contributes N. Keep going down the table.','The six letters are I, N, V, I, T, E. Read the word in the letter.')]

def guide(path,size):
    begin(path,size,'Help and answers')
    page('Keep separate','Help & answers','Set up without spoilers. This file is for the whole crew, only when needed.')
    para(0,145,'<b>Print check.</b> Use the game PDF that matches your paper size. Select single-sided printing and fit to printable area if needed. No puzzle depends on exact scale, color, folding or double-sided alignment. Check that grid letters and the small lantern labels are readable.',size=12,leading=18)
    para(0,251,'<b>Setup without answers.</b> Print game pages 1-7. Put the ledger in the center, hand out A-D and set the finale face down. Page 8 is optional. This Help PDF may stay on a device or be printed separately. Do not print it on the back of a role sheet.',size=12,leading=18)
    para(0,357,'<b>Hints.</b> Find your job on the next two pages. Read only Nudge 1. If that is not enough, read Nudge 2 and then Nudge 3. No penalties. Players can use a spare sheet to cover later nudges. Full answers start on page 4.',size=12,leading=18)
    para(0,462,'<b>Group size.</b> Four players each take one role. Two players take two each; some jobs will be on one person\'s sheets, so read clues aloud and solve together. Three players combine any two roles. Five or six share roles; let quieter players be the final checker. For larger groups, print another full set and split into teams.',size=12,leading=18)
    para(0,586,'<b>Adapt.</b> There is no required timer. Read any small text aloud. Show pages freely if the explain-first challenge becomes frustrating. The game is English and assumes basic reading, alphabet order and addition/subtraction. Ages and duration still need family playtesting.',size=11.5,leading=17)
    footer()
    for group in [HINTS[:3],HINTS[3:]]:
        page('Progressive hints','A nudge, not a spoiler','Read only the next nudge for the job you are solving.')
        y=146
        for title,a,b,c in group:
            text(0,y,title,15,'Bold',TEAL);y+=28
            for j,h in enumerate([a,b,c]):
                ph=para(0,y,f'<b>Nudge {j+1}.</b> '+h,width=520,size=10.8,leading=15)
                y+=ph+10
            y+=20
        footer()
    page('Spoilers start here','How every job works','Full answers. Stop here if you only want a hint.')
    y=146
    for p in DATA['puzzles'][:3]:
        text(0,y,f"{p['id']} / {p['answer']}",17,'Bold',TEAL);y+=32
        y+=para(0,y,p['solution'],size=12,leading=18)+28
    para(0,643,'No alternate spelling or case-sensitive entry is required. The game is fully offline. Compare the reasoning, not only the final word.',size=11,leading=16,color=GRAY)
    footer()
    page('Full answers','The final repairs','Jobs 4-7 and the ending. Read the ending aloud once your final word is found.')
    y=141
    for p in DATA['puzzles'][3:]:
        text(0,y,f"{p['id']} / {p['answer']}",14,'Bold',TEAL);y+=25
        y+=para(0,y,p['solution'],size=10.8,leading=15)+17
    text(0,y+4,'The ending',18,'Display');y+=37
    para(0,y,'The tower lantern blinks three times. A reply arrives, written in Mara\'s careful hand:<br/><br/>"I thought the last letter would be another delivery. I did not expect it to be for me. Keep the soup warm. I\'m on my way."<br/><br/>For once, the keeper leaves the tower before midnight. Below, a little line of lanterns leads to a table with one empty chair. Your crew has sent the most important signal of the night: there is room for one more.',size=11.3,leading=16)
    footer();C.save()

def demo(path,size):
    begin(path,size,'Free two-player sample')
    page('Free sample / 2 players','Can you send a warm signal?','One tiny cooperative puzzle. A taste of The Christmas Signal, not part of the paid adventure.')
    para(0,139,'One player reads the map. The other reads the route. Explain what you see before comparing pages. You may cover either half with spare paper. Start at A3, do not record the starting letter, and record each landing letter.',size=11.5,leading=17)
    box(0,227,250,262,None,TEAL);box(270,227,250,262,None,TEAL)
    text(16,245,'PLAYER 1 / MAP',12,'Bold',TEAL);text(286,245,'PLAYER 2 / ROUTE',12,'Bold',TEAL)
    g=[['B','R','M'],['W','A','F'],['S','N','E']]
    for j,v in enumerate('ABC'):text(60+j*48,282,v,11,'Bold')
    for i,row in enumerate(g):
        text(28,319+i*48,str(i+1),10,'Bold')
        for j,k in enumerate(row):box(49+j*48,305+i*48,48,48,None,GRAY);text(65+j*48,316+i*48,k,20,'Bold')
    para(286,296,'Move from each landing square:<br/><br/>1. North 1 square<br/>2. East 1 square<br/>3. North 1 square<br/>4. East 1 square',width=217,size=12,leading=22)
    text(16,467,'North is up. Start at A3.',10)
    text(286,467,'Read only landing letters.',10)
    text(0,520,'Your four-letter signal:  ____  ____  ____  ____',15,'Bold')
    para(0,567,'Like solving together? The full adventure has four role sheets, six paired jobs and a final letter to complete. No scissors, physical locks or internet needed during play.',size=11.5,leading=17)
    para(0,648,'Answer below. Cover this line until you have tried.<br/><b>A3 → A2 → B2 → B1 → C1 gives W A R M.</b><br/>Free to share this complete sample, unchanged. Do not share the full game.',size=10,leading=14,color=GRAY)
    footer();C.save()

if __name__=='__main__':
    for label,size in [('A4',A4),('USLetter',letter)]:
        game(ROOT/f'customer/01_Game_{label}.pdf',size)
        guide(ROOT/f'customer/02_Help_Answers_{label}.pdf',size)
        demo(ROOT/f'seller/Free_Sample_{label}.pdf',size)
    print('Created 4 customer PDFs and 2 sample PDFs.')
