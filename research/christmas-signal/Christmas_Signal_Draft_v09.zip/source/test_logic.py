"""Deterministic checks of every puzzle. This is logic QA, not a human playtest."""
import itertools,json
from pathlib import Path
root=Path(__file__).resolve().parents[1]
d=json.loads((root/'source/content.json').read_text())
checks=[]
def check(name, actual,expected):
 assert actual==expected,(name,actual,expected)
 checks.append({'check':name,'actual':actual,'expected':expected,'status':'PASS'})
# 1: map walk; no out-of-bounds movement, landing letters only.
grid=d['grid'];r,c=3,0;out=''
for dr,dc,dist in [(-1,0,2),(0,1,2),(1,0,1),(0,-1,1)]:
 for _ in range(dist):
  r+=dr;c+=dc;assert 0<=r<4 and 0<=c<4
 out+=grid[r][c]
check('1 route',out,'PINE')
# 2: enumerate all schedules, rather than assuming uniqueness.
valid=[]
for p in itertools.permutations(['Robin','Fox','Hare','Owl']):
 if p.index('Owl')==3 and p.index('Fox')==p.index('Robin')+1 and p.index('Hare')==p.index('Fox')+1:valid.append(p)
check('2 unique timetable count',len(valid),1)
letters={'Robin':'S','Fox':'N','Hare':'O','Owl':'W'}
check('2 timetable word',''.join(letters[a] for a in valid[0]),'SNOW')
# 3: brute force positive whole numbers supported by the key.
v=[(m,b,s,e) for m,b,s,e in itertools.product(range(1,7),repeat=4) if m+b==9 and b+s==7 and s+m==8 and e+s==5]
check('3 unique balance solution',v,[(5,4,3,2)])
key={1:'R',2:'E',3:'V',4:'O',5:'D',6:'A'}
check('3 weight word',''.join(key[n] for n in v[0]),'DOVE')
# 4: reverse then alphabet decrement with wrap.
def repair(raw):return ''.join(chr((ord(k)-65-1)%26+65) for k in raw[::-1])
check('4 telegram',repair('UGJH'),'GIFT')
check('4 worked example',repair('BA'),'ZA')
# 5: all 36 home+gift permutations, apply only printed clues.
solutions=[]
for hs in itertools.permutations(['Bakery','Orchard','Tower']):
 for gs in itertools.permutations(['STAR','BELL','DRUM']):
  homes=dict(zip(['Ari','Bea','Cal'],hs));gifts=dict(zip(['Ari','Bea','Cal'],gs))
  tower=next(n for n,h in homes.items() if h=='Tower')
  if homes['Ari']=='Bakery' and gifts[tower]=='BELL' and gifts['Bea']=='DRUM' and homes['Bea']!='Tower':solutions.append((homes,gifts))
check('5 unique delivery solution count',len(solutions),1)
check('5 bakery gift',solutions[0][1]['Ari'],'STAR')
# 6: all distinct four-panel chains, no reuse.
chains=[]
for perm in itertools.permutations(d['panels'],4):
 if perm[0][1]=='START' and perm[-1][2]=='END' and all(perm[i][2]==perm[i+1][1] for i in range(3)):
  chains.append(perm)
check('6 unique chain count',len(chains),1)
check('6 panel numbers',[p[0] for p in chains[0]],[4,1,6,2])
check('6 panel word',''.join(p[3] for p in chains[0]),'TREE')
# 7: meta from the verified answers.
check('7 meta',''.join(p['answer'][p['index']-1] for p in d['puzzles'][:6]),'INVITE')
# Demo: independent grid/directions.
g=[list('BRM'),list('WAF'),list('SNE')];r,c=2,0;out=''
for dr,dc in [(-1,0),(0,1),(-1,0),(0,1)]:r+=dr;c+=dc;out+=g[r][c]
check('free sample',out,'WARM')
# Pair incidence: every unordered pair of four roles is used once.
check('six distinct pairs',len(set(tuple(p['pair']) for p in d['puzzles'][:6])),6)
result={'kind':'automated exhaustive logic QA; no human playtest','checks':checks,'count':len(checks)}
(root/'qa/logic-results.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2))
