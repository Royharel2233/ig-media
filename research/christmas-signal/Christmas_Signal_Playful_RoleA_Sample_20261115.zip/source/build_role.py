from pathlib import Path
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.pagesizes import A4,letter
from reportlab.lib.colors import HexColor,white
from reportlab.platypus import Paragraph
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.utils import ImageReader
from PIL import Image,ImageOps,ImageDraw
import pymupdf as fitz
R=Path(__file__).resolve().parents[1]
for n,p in [('Body','NotoSans-Regular.ttf'),('Bold','NotoSans-Bold.ttf'),('Display','NotoSerif-Bold.ttf')]:pdfmetrics.registerFont(TTFont(n,'/usr/share/fonts/truetype/noto/'+p))
INK='#233e4b';BLUE='#116493';RED='#b93532';GREEN='#236a53';GOLD='#d69d25'

def build(path,size):
 w,h=size;c=canvas.Canvas(str(path),pagesize=size);c.setTitle('The Christmas Signal | Role A playful sample');c.setAuthor('Letterlight Dispatch');x=(w-520)/2
 def text(xx,t,s,size=11,font='Body',col=INK):c.setFillColor(HexColor(col));c.setFont(font,size);c.drawString(x+xx,h-t-size*.83,s)
 def para(xx,t,s,width=488,size=10.5,lead=15,col=INK):
  p=Paragraph(s,ParagraphStyle('p',fontName='Body',fontSize=size,leading=lead,textColor=HexColor(col)));_,ph=p.wrap(width,500);p.drawOn(c,x+xx,h-t-ph);return ph
 def box(xx,t,bw,bh,fill,stroke=None,r=8):
  c.setFillColor(HexColor(fill));c.setStrokeColor(HexColor(stroke or fill));c.setLineWidth(.9);c.roundRect(x+xx,h-t-bh,bw,bh,r,stroke=bool(stroke),fill=True)
 def line(xx,t,xx2,t2,col=INK,width=1):c.setStrokeColor(HexColor(col));c.setLineWidth(width);c.line(x+xx,h-t,x+xx2,h-t2)
 # Header: reference-consistent illustration, all functional text remains true typeset data.
 if (R/'art/Fox_Header.png').exists():c.drawImage(str(R/'art/Fox_Header.png'),x+207,h-169,width=313,height=150,mask='auto',preserveAspectRatio=True,anchor='c')
 text(0,22,'THE CHRISTMAS SIGNAL',9,'Bold',RED)
 box(0,47,68,26,BLUE,r=5);text(11,53,'ROLE A',11,'Bold','#ffffff')
 text(0,87,'The route',25,'Display');text(0,119,'keeper',25,'Display')
 text(0,161,'Your clues matter. Share them with your partner.',10.4,'Bold',BLUE)
 text(350,173,'Illustration, not a clue.',7.5,col=INK)
 # Stamp divider, postal visual system without hiding any instructions.
 line(0,186,520,186,BLUE,1.4)
 for i in range(23):c.setFillColor(white);c.circle(x+8+i*23,h-186,2.6,stroke=0,fill=1)
 def panel(t,height,n,title,partner,color):
  box(0,t,520,height,'#ffffff','#b9cbd0',10)
  box(0,t,520,33,color,r=8)
  # straighten lower part of title strip
  c.setFillColor(HexColor(color));c.rect(x,h-t-33,520,13,stroke=0,fill=1)
  box(10,t+6,25,21,'#fff8df',r=4);text(18,t+10,str(n),12,'Bold',color)
  text(45,t+9,title,13,'Bold','#ffffff')
  c.setFont('Bold',9.5);c.setFillColor(white);c.drawRightString(x+506,h-t-21,'WITH '+partner)
  return t+46
 # Fit US Letter as well; fixed content bottom 724, footer 756.
 t=panel(202,168,1,'Find the route','B',BLUE)
 text(13,t,'Map: north is up. Columns A-D; rows 1-4.',10)
 gx=190;gy=t+29;sz=21
 for j,k in enumerate('ABCD'):
  tw=pdfmetrics.stringWidth(k,'Bold',9);text(gx+j*sz+(sz-tw)/2,gy-15,k,9,'Bold',BLUE)
 grid=[list('KFMR'),list('PAIS'),list('TENO'),list('DGWL')]
 for i,row in enumerate(grid):
  text(gx-16,gy+i*sz+6,str(i+1),9,'Bold',BLUE)
  for j,k in enumerate(row):
   box(gx+j*sz,gy+i*sz,sz,sz,'#f2f8fb','#668c9d',0);tw=pdfmetrics.stringWidth(k,'Bold',11);text(gx+j*sz+(sz-tw)/2,gy+i*sz+5,k,11,'Bold')
 para(315,t+35,'The depot is A4.<br/>Start on its D.<br/>Do not record D.<br/>B holds the route.',width=190,size=10.5,lead=16)
 t=panel(382,155,3,'Balance the mail','C',GREEN)
 para(13,t,'Each item always has the same whole-number weight. C has the label key and reading order.',width=490,size=10.2,lead=14)
 eqs=['MITTEN + BELL = 9','BELL + STAR = 7','STAR + MITTEN = 8','ENVELOPE + STAR = 5']
 for i,eq in enumerate(eqs):
  xx=13+(i%2)*249;yy=t+37+(i//2)*31;box(xx,yy,241,26,'#f0f8f1','#aacbb8',4);text(xx+10,yy+8,eq,10,'Bold',GREEN)
 t=panel(549,164,5,'Deliver the parcels','D',RED)
 para(13,t,'Three residents. Three homes. Three gifts. Each person has exactly one home and one gift; nothing repeats. D holds four witness clues.',width=490,size=10.2,lead=14)
 for i,(lab,items) in enumerate([('RESIDENTS','Ari  /  Bea  /  Cal'),('HOMES','Bakery  /  Orchard  /  Tower'),('GIFTS','STAR  /  BELL  /  DRUM')]):
  yy=t+41+i*24;box(13,yy,82,18,'#fff1e7',r=3);text(19,yy+5,lab,8,'Bold',RED);text(108,yy+3,items,10.4,'Bold')
 line(0,734,520,734,'#a8c2c7',.6)
 text(0,746,'ONE ROLE-SHEET DESIGN SAMPLE  /  v0.9.1 puzzle content unchanged',7.8,'Bold',BLUE)
 text(0,761,'Use with the existing game ledger and roles B-D. Not a complete new edition.',7.6,col=INK)
 c.showPage();c.save()

if __name__=='__main__':
 for label,size in [('A4',A4),('USLetter',letter)]:
  p=R/f'Role_A_Playful_Sample_{label}.pdf';build(p,size)
  d=fitz.open(p);d[0].get_pixmap(matrix=fitz.Matrix(1.8,1.8),alpha=False).save(R/'renders'/f'Role_A_{label}.png')
 im=Image.open(R/'renders/Role_A_A4.png');im.thumbnail((650,920));im.save(R/'Role_A_Preview.jpg',quality=95)
 print('Built actual one-page role sample in both paper sizes.')
