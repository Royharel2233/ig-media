# Role-A sample checks

Initial A4 revision: independent review inspected actual PDF pixels and verified exact clue equivalence to the existing v0.9.1 role A: grid, equations, jobs 1/3/5 and partner links. No clipping or overlap found. Functional clues remain embedded typeset text, not generated image lettering.

Final bounded change: added "Illustration, not a clue." under decorative header art. The final A4 delta was checked directly against the preceding PDF extraction and preview: only that label and extraction whitespace changed, no clue words or numbers. Final A4 and Letter were visually inspected by the author; both passed content checks and safe text bounds. A grayscale render was inspected and remained readable. Final Letter was not independently reviewed. Independent review of the earlier A4 is not claimed as an independent review of every final file.

No physical printer or real-family playtest occurred. Ink use, age, playtime, demand, conversion and support burden remain unvalidated. This is one visual sample, not a complete revised edition.
