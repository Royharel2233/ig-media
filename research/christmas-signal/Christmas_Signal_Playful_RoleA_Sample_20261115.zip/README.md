# One playful role-sheet sample
15 November 2026. The Christmas Signal. This is ONE role-A sheet for design approval, in A4 and US Letter, not a complete restyled game edition.

Use with the existing v0.9.1 mission ledger and role sheets B-D. Jobs 1, 3 and 5 preserve their original clue content, grid letters, equations, resident/home/gift lists and partner letters. No answer, rule or story text elsewhere in the game has changed. The existing complete pack remains unchanged.

Design: reference-consistent fox with blue satchel as role-A anchor, bright postal job headers and numbered labels. White main paper surface and clear typeset functional clues, not an AI-rendered grid or generated clue lettering. The header map illustration is decorative and explicitly labelled "Illustration, not a clue." Color is not required to identify any job or fact. Color headers and illustration consume more ink than the old sheet; no reduced-ink-cost claim is made.

Checks: both PDFs rendered and actual pixels inspected, including a grayscale render. Functional text/data checks and safe text bounds passed. Independent review status is reported separately with delivery. Digital grayscale inspection is not a physical printer test, age validation or a family playtest. No demand/conversion/virality evidence is claimed.

The illustration is AI-generated using the approved concept as a visual reference. Original source image, editable ReportLab source, Noto font licence and content-check results are included. No competitor assets, private user facts or operational records. Full illustration consistency across future pages still requires review. Working imprint and all earlier release gates remain open.

No shop, listing, publication, signup or spending action occurred. This is the single sample requested before any global redesign. If approved, apply the visual language carefully to the rest of the kit while preserving functional content, print readability and independent QA. Do not call the current complete kit already redesigned.
