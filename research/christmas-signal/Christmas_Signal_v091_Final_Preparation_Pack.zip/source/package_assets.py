from pathlib import Path
import re,html,json
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, KeepTogether
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from PIL import Image,ImageDraw,ImageFont,ImageOps,ImageFilter
import pymupdf as fitz
import build_game as b
R=Path(__file__).resolve().parents[1]

def pdf_md(src,dst):
    styles={
      'title':ParagraphStyle('t',fontName='Display',fontSize=23,leading=30,textColor=b.INK,spaceAfter=22),
      'head':ParagraphStyle('h',fontName='Bold',fontSize=14,leading=20,textColor=b.TEAL,spaceBefore=18,spaceAfter=9,keepWithNext=True),
      'body':ParagraphStyle('p',fontName='Body',fontSize=10.5,leading=16,textColor=b.INK,spaceAfter=10),
    }
    story=[]
    md=re.sub(r'(?m)^(#{1,2} [^\n]+)$',r'\n\n\1\n\n',src.read_text())
    for par in md.split('\n\n'):
      par=par.strip()
      if not par:continue
      typ='title' if par.startswith('# ') else 'head' if par.startswith('## ') else 'body'
      par=re.sub(r'^#{1,2} ','',par)
      s=html.escape(par).replace('\n','<br/>')
      s=re.sub(r'(https://[^\s<]+)',r'<link href="\1" color="#27655d">\1</link>',s)
      story.append(Paragraph(s,styles[typ]))
    def foot(c,doc):
      c.setFont('Body',8);c.setFillColor(b.GRAY);c.drawString(42,28,'The Christmas Signal | Working product pack | 15 November 2026');c.drawRightString(A4[0]-42,28,str(doc.page))
    SimpleDocTemplate(str(dst),pagesize=A4,leftMargin=42,rightMargin=42,topMargin=42,bottomMargin=48).build(story,onFirstPage=foot,onLaterPages=foot)

for src,dst in [(R/'research/report.md',R/'research/Research_and_Product_Decisions.pdf'),(R/'seller/Listing_and_Promotion_DRAFT.md',R/'seller/Listing_and_Promotion_DRAFT.pdf'),(R/'seller/Release_Checklist_and_Playtest.md',R/'seller/Release_Checklist_and_Playtest.pdf')]:pdf_md(src,dst)

# Render every page of every edition and create contact sheets for pixel review.
for pdf in list((R/'customer').glob('*.pdf'))+list((R/'seller').glob('*.pdf'))+list((R/'research').glob('*.pdf')):
    d=fitz.open(pdf);thumbs=[]
    for i,p in enumerate(d):
      pix=p.get_pixmap(matrix=fitz.Matrix(1.35,1.35),alpha=False)
      path=R/'renders'/f'{pdf.stem}_{i+1:02}.png';pix.save(path)
      im=Image.open(path);im.thumbnail((306,433));tile=Image.new('RGB',(326,467),'#dedede');tile.paste(im,((326-im.width)//2,8));ImageDraw.Draw(tile).text((7,447),f'{pdf.stem} / {i+1}',fill='black');thumbs.append(tile)
    sheet=Image.new('RGB',(326*4,467*((len(thumbs)+3)//4)),'white')
    for i,t in enumerate(thumbs):sheet.paste(t,((i%4)*326,(i//4)*467))
    sheet.save(R/'renders'/f'{pdf.stem}_contact.png')

# Original listing images using actual rendered pages, no fake photographs.
FONT='/usr/share/fonts/truetype/noto/NotoSans-Regular.ttf';BOLD='/usr/share/fonts/truetype/noto/NotoSans-Bold.ttf';DISPLAY='/usr/share/fonts/truetype/noto/NotoSerif-Regular.ttf'
TEAL='#27655d';INK='#242d35';BG='#f4efec'
def font(s,bold=False,display=False):return ImageFont.truetype(DISPLAY if display else BOLD if bold else FONT,s)
def base(k,title,sub):
 im=Image.new('RGB',(2000,1500),BG);d=ImageDraw.Draw(im)
 d.text((90,60),'LETTERLIGHT DISPATCH  /  THE CHRISTMAS SIGNAL',font=font(24,True),fill=TEAL)
 d.text((90,120),title,font=font(67,display=True),fill=INK)
 d.text((94,230),sub,font=font(29),fill=INK)
 d.text((90,1420),'Actual PDF previews • Playtest candidate v0.9.1 • Not a physical product',font=font(22),fill=TEAL)
 return im,d

def paper(im,stem,x,y,h):
 p=Image.open(R/'renders'/f'{stem}.png').convert('RGB');p=ImageOps.contain(p,(1000,h));
 sh=Image.new('RGBA',(p.width+34,p.height+34));ImageDraw.Draw(sh).rectangle((14,14,p.width+16,p.height+16),fill=(0,0,0,45));sh=sh.filter(ImageFilter.GaussianBlur(8));im.paste(sh,(x-10,y-8),sh);im.paste(p,(x,y));return p.width

im,d=base(1,'One last letter. Four pairs of hands.','A no-cut cooperative Christmas paper adventure.')
paper(im,'01_Game_A4_01',1050,345,990)
d.text((95,450),'SHARE THE CLUES.',font=font(38,True),fill=TEAL)
for j,t in enumerate(['4 role sheets','6 paired jobs + 1 final message','Paper + pencils','A4 and US Letter','Offline hints and full answers']):d.text((95,555+j*99),t,font=font(34),fill=INK)
im.save(R/'seller/Listing_01_Cover.jpg',quality=94)

im,d=base(2,'A complete little mission.','7 essential game sheets + optional celebration. Separate 5-page help guide.')
for i,stem in enumerate(['01_Game_A4_01','01_Game_A4_02','01_Game_A4_03','02_Help_Answers_A4_01']):paper(im,stem,90+i*475,385,630)
d.text((95,1110),'Both paper sizes included. Print only the edition you need.',font=font(36,True),fill=TEAL)
d.text((95,1190),'No color-only clues. No scissors, locks, app or internet during play.',font=font(31),fill=INK)
im.save(R/'seller/Listing_02_Inside.jpg',quality=94)

im,d=base(3,'Nobody holds the whole answer.','Every pair of roles works together once. Then everyone joins for the finale.')
for i,(round_,pairs) in enumerate([('ROUND 1','A + B     C + D'),('ROUND 2','A + C     B + D'),('ROUND 3','A + D     B + C')]):
 x=90+i*630;d.rounded_rectangle((x,440,x+585,890),radius=24,fill='white');d.text((x+42,500),round_,font=font(34,True),fill=TEAL)
 d.text((x+42,640),pairs,font=font(37,True),fill=INK)
d.text((95,1050),'Map navigation • Ordering • Balance equations',font=font(35),fill=INK)
d.text((95,1130),'Alphabet repair • Deduction • Lantern chain • Final extraction',font=font(32),fill=INK)
d.text((95,1250),'Best with 4. Two to six can share or combine roles.',font=font(32,True),fill=TEAL)
im.save(R/'seller/Listing_03_Together.jpg',quality=94)

im,d=base(4,'Print. Share. Send the signal.','No cutting, no prop hunt, no host reading the solutions first.')
for i,(n,tt,body) in enumerate([('01','PRINT','Match the PDF to your paper size.\nPrint game pages 1-7 single-sided.'),('02','SHARE','Put the ledger in the center.\nGive out roles A-D.'),('03','SOLVE','Work in pairs. Use the hints\nwhenever you need a nudge.')]):
 y=400+i*300;d.text((95,y),n,font=font(75,display=True),fill=TEAL);d.text((280,y+2),tt,font=font(42,True),fill=INK);d.multiline_text((280,y+80),body,font=font(32),spacing=15,fill=INK)
im.save(R/'seller/Listing_04_Setup.jpg',quality=94)

im,d=base(5,'Try a tiny mission together.','A complete free two-player sample. Answer included. No signup required in the file.')
paper(im,'Free_Sample_A4_01',100,330,1010)
d.text((1010,510),'One has the map.',font=font(45,display=True),fill=INK)
d.text((1010,610),'One has the route.',font=font(45,display=True),fill=INK)
d.text((1010,760),'Can you send a warm signal?',font=font(30,True),fill=TEAL)
d.multiline_text((1010,900),'Share the complete free sample,\nnot the full-game answer sheets.\n\nSharing is optional.\nNo measured virality is claimed.',font=font(29),spacing=18,fill=INK)
im.save(R/'seller/Listing_05_Sample.jpg',quality=94)
# Image review contact sheet.
files=sorted((R/'seller').glob('Listing_*.jpg'));sheet=Image.new('RGB',(1500,600*((len(files)+1)//2)),'white')
for i,p in enumerate(files):
 im=Image.open(p);im.thumbnail((750,562));sheet.paste(im,((i%2)*750,(i//2)*600))
sheet.save(R/'renders/Listing_Images_contact.jpg',quality=95)
print('Report PDFs, all-page renders and five listing image drafts built.')
