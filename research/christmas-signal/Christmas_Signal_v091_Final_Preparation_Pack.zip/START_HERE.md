# Start here: your game is built
The Christmas Signal | v0.9.1 | Ready for family playtesting, not for sale yet.

## Play the actual product
Open customer/01_Game_A4.pdf, or choose 01_Game_USLetter.pdf if that matches your printer. Print pages 1-7 single-sided. Page 8 is an optional celebration sheet. Keep the matching 02_Help_Answers PDF separate. Paper and pencils are enough. No cutting, locks, app or internet required during play.

Four role sheets share the information. Each of the six role pairs solves one job, then everyone uses the six answers for the final message. The complete game, hints, solutions and ending are included. Nothing depends on an unfinished online service.

## Why this product, not the earlier missing-star idea
The specific position is "no-cut preparation + shared clues + a coherent story payoff". Specialist reviews of existing games describe preparation that outlasts play, confusing instructions and weak narrative links. We designed around those problems. Role-based play and hints already exist elsewhere: this is a quality combination, not a claim that we invented the category or have a protected moat.

The new postal story ends with an invitation for a lonely tower keeper. Every pair of roles is used once, so sharing is part of the puzzles rather than a decoration on the cover. Seven essential sheets replace a pile of cut-out props. There is a tradeoff: this is a light tabletop adventure, not a cinematic physical room.

## Everything prepared
customer/: four print-ready PDFs, both paper sizes, plus licence/readme.
seller/: complete free two-player sample in both sizes; five listing image drafts made from actual pages; title, description, price-test recommendation, FAQ, buyer note, support response drafts, three free promotion concepts, release checklist and family test form. No posts or videos were published.
research/: sourced competitor/product/channel report, source ledger and decision notes.
source/: editable story/content and PDF/image-generation sources, plus font licence.
qa/: logic results and independent-review status.

## The sharing idea
The free sample gives one person a map and another a route. It is meant to be tried with a second person, then shared unchanged. The optional celebration sheet lets a crew share a memory without puzzle spoilers, faces or names. These are testable sharing ideas, not proven virality. No traffic, sales or referral results exist yet.

## What passed, and what is still open
Independent desk review solved all seven puzzles blind, matched hints/answers and confirmed all six role pairings. All 15 automated logic/uniqueness checks passed again. Corrected A4 and Letter layouts and the sample were rechecked. This is real desk QA, not a human family playtest.

Before sale: print both sizes in grayscale; test with at least three consenting family groups; measure setup, playtime, participation and confusion; resolve the working imprint and platform/payment eligibility; review seller terms, consumer rights, tax and support details; approve the final words and any store/account action. Age 8+, duration, ten-minute daily workload, sales and sharing performance are not validated by desk review.

Etsy eligibility for this AI-assisted workflow remains unresolved, not a confirmed ban or approval. Payhip explicitly supports AI downloads but would still require account/payment checks and our own traffic. No shop was opened, no money spent and nothing listed for sale.

Recommended next step: play the actual files, not another planning round. Use seller/Release_Checklist_and_Playtest.pdf to record what happens. If a clue needs designer intervention, fix it before release. The source files are included so changes do not require starting over.
