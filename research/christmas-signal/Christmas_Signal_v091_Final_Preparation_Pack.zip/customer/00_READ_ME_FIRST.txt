THE CHRISTMAS SIGNAL - v0.9.1 PLAYTEST CANDIDATE

This is a complete playable candidate, not a validated commercial release.

PRINTING
Choose either the A4 or USLetter game PDF and matching Help_Answers PDF. You do not need both paper sizes. Print game pages 1-7 single-sided; page 8 is optional. Ordinary paper and pencils are enough. No cutting, lock, app or internet needed during play. Keep Help_Answers separate to avoid spoilers.

PERSONAL-PLAY LICENCE
The supplied game and help files may be printed for private, non-commercial play by the recipient's household and personal guests. You may print fresh copies for another private game with your own guests. Do not resell, redistribute, upload or share these full-game digital files. No institutional, paid-event, classroom or commercial licence is included. These conditions do not limit any non-waivable rights under applicable law.

FREE SAMPLE
The separate Free_Sample PDFs may be shared unchanged, at no charge, with their attribution and answer intact. This permission applies only to the free sample, not the full game.

STATUS
All puzzle answers have desk/logic checks. Real family testing and home-printer tests are still required. Ages and playtime are not human-validated. AI assisted story, puzzle development and layout. The working imprint is not trademark-cleared.
