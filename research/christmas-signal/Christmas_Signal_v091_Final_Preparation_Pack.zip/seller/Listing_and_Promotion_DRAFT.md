# Store copy and free promotion drafts
Status: NOT PUBLISHED. Use only after the release checklist passes, seller/platform eligibility is resolved, and the owner approves the words and actions. Working name/imprint is not legally cleared.

## Product title
The Christmas Signal | Cooperative Printable Christmas Escape Game | 4 Roles, 7 Puzzles | A4 + US Letter

## One-line position
One last letter. Four pairs of hands. A no-cut Christmas paper adventure made to solve together.

## Description draft
The village lantern has gone dark, and the Letterlight post office still has one letter to deliver. Your crew holds different pieces of the mission. Share the clues, repair six dispatch jobs and uncover the final message.

The Christmas Signal is a cooperative tabletop escape adventure, not a set of hidden clues around your home. Four role sheets spread the information across the table. Each pair works together once, then everyone joins for the final dispatch.

What's included:
- 8-page player game: 7 essential sheets plus an optional celebration keepsake.
- Separate 5-page Help & Answers guide with three progressive nudges for every puzzle, full solutions and story ending.
- Both A4 and US Letter editions. Four PDFs in total.
- Six paired puzzles plus a final extraction puzzle: map navigation, ordering, balance equations, alphabet repair, delivery deduction and a lantern chain.

What you need: printer, ordinary paper and pencils. Print single-sided. No cutting, tape, physical locks, special props, internet or app required during play. Color is optional; clues do not depend on color. Print one set per team.

Best with 4 players. Two to six can play by sharing or combining roles. Designed for ages 8+ with adult reading support. Experienced adult puzzlers should expect a light challenge, not a difficult escape-room challenge. Play at your own pace. [Before publication, replace this internal note with a measured playtime only if real testing supports it.]

This is a digital download. No physical item is shipped. Print the paper-size edition you need; you do not need to print both. Read the first game page before printing the rest. Keep the separate answers PDF closed unless needed.

Personal play only under the included licence. No resale, re-upload or commercial event use. Nothing here limits rights buyers have under applicable law.

AI-assisted story, puzzle development and layout, with editorial and technical review. [Owner must personally review the actual product and approve this disclosure and any platform-specific wording. This draft does not imply marketplace eligibility.]

Try the free two-player sample before choosing the full adventure. [Insert only a verified live sample link after separately approved hosting. No link exists yet.]

## Proposed price test
$7.90 one-time. Not a fake discount, not an approved live price, and no earnings promise. Do not publish a crossed-out reference price that was never charged.

## Marketplace keyword drafts
christmas escape; family puzzle game; printable adventure; cooperative game; christmas activity; paper escape game; family game night; no cut printable; christmas puzzles; four player game; christmas party; instant download; puzzle adventure
These are relevance suggestions, not verified search volumes. Adapt only to the chosen platform's current rules and field limits. Do not add competitor names or "bestseller".

## Buyer note draft
Thank you for choosing The Christmas Signal. Download the A4 or US Letter game for your printer and the matching Help & Answers guide. Print game pages 1-7 single-sided; page 8 is optional. Keep the answers separate. No scissors, locks or internet are needed during play. If something looks wrong, contact us through the shop's message channel with the PDF name and page number. Please do not send children's personal information.

## FAQ
Q: Is anything mailed?
A: No. These are downloadable PDF files for you to print.
Q: Do I need a color printer?
A: No puzzle uses color as its only clue. Print at a readable size; use the grayscale test before release.
Q: Does the host have to know the answers?
A: No. Setup uses only the first player page. The guide is separate.
Q: Is this a real locked room?
A: No. It is a tabletop paper adventure. Never lock players in a room.
Q: Can two people play?
A: Yes, by combining roles. The paired-information structure works best with four. Some jobs may be on one person's combined sheets, so solve together.
Q: Can I replay it?
A: You will know the solutions after one play. Another group may use a fresh printed set for personal play. It is not a randomized replay game.
Q: Can I personalize names or request a harder edition?
A: No custom versions are currently offered.
Q: Can I use it in a paid event, classroom or business?
A: The included licence covers private personal play only. No commercial or institutional licence is offered in this draft.
Q: Is there an app or QR code?
A: No. The game and help are complete offline PDFs.
Q: What is the refund policy?
A: Use the seller's actual published policy and applicable consumer law. Do not make a blanket "no refunds" promise in this draft.

## Support response drafts, not automatic sends
Printing: "Please check that your PDF and printer paper size match, choose single-sided printing and use fit to printable area if needed. The puzzles do not depend on exact scale. Which PDF and page are affected? Please send a close-up of only the affected printed area, without personal details."
Clue confusion: "Please tell us the job number and the last step that made sense. Each job has three progressive nudges in the separate Help & Answers guide. I can point you to the next nudge without spoiling the later jobs."
File access: "Please use the download link provided by the shop where you purchased. If it fails, send the order reference through that shop's private message channel. Do not post it in a review."
Do not promise a response time the owner has not agreed to meet. Do not auto-send these before a shop and scope are approved.

## Free promotion concept 1: the paired clue
Creative: show the actual free sample, one half at a time, then both halves. No actors, fabricated play reaction or mock customer testimonial.
Hook: "One of you has the map. One of you has the route. Can you send a warm signal?"
Caption: "Try this tiny two-person Christmas puzzle. Read one half each before comparing. The complete free sheet includes the answer. The full Christmas Signal adventure uses four roles and six paired jobs."
CTA: "Try the free sample." Add a live URL only after approval and verification.
This is a static storyboard, not a finished video. If a video is later produced, it needs its own frame review before sending or posting.

## Free promotion concept 2: preparation contrast
Creative: real player PDF pages beside paper and a pencil. Do not imply a photographed printed prototype if using a rendered digital preview.
Hook: "A Christmas escape game. Without the hour of cutting."
Safer launch wording until setup is physically tested: "No cutting. No locks. Just paper, pencils and shared clues."
Caption: "The Christmas Signal is a printable tabletop adventure with four role sheets, six paired jobs and one final message. See the actual pages and try the free two-player sample first."
Do not make comparative superiority or timed-setup claims without evidence from this product.

## Free promotion concept 3: spoiler-free memory
Creative: optional celebration sheet, no faces/names visible.
Hook: "What was your crew's best teamwork moment?"
Caption: "Keep the memory, not the spoilers. If your whole crew is comfortable, share your celebration sheet without names, faces or puzzle answers. Sharing is optional."
No discount or prize for a positive review. No guaranteed referral loop.

## Rights and release notes
All customer assets were newly composed for this project. No competitor art, paid files, lyrics, logos or photographs are included. Diagrams and skyline are original vector drawings. Fonts are embedded from Noto with its licence in source. Common puzzle mechanics are not exclusive intellectual property. AI-generated elements may have limited copyright protection; no legal exclusivity is claimed. Seller must verify its own rights, name and policy eligibility before launch.
