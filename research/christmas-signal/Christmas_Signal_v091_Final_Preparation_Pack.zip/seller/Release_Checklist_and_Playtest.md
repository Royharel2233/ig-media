# Release checklist and field-test sheet
Version 0.9.1. A complete playable candidate, not commercially validated.

## Files buyers receive after release approval
- 01_Game_A4.pdf: 8 pages, 7 essential + optional celebration.
- 01_Game_USLetter.pdf: same game for US Letter.
- 02_Help_Answers_A4.pdf: 5 pages, separate hints/solutions/ending.
- 02_Help_Answers_USLetter.pdf: same guide for US Letter.
Upload all four as fixed downloads, not made-to-order customization. Buyer prints only one paper-size edition. Source, research, marketing drafts and this checklist are not buyer files.

## Required before sale
[ ] Independent desk QA reviewed and all release-blocking issues fixed.
[ ] Both editions physically printed, single-sided, grayscale, on an ordinary home printer. No cropped or unreadable labels/letters.
[ ] At least 3 consenting real family groups test without live designer help. Include at least 2 mixed-age groups with an 8-10-year-old and adult.
[ ] Every printed puzzle solved correctly and no ambiguous clues left.
[ ] All four roles participate; fix spectator roles and bottlenecks.
[ ] Setup and play times measured, not guessed. Set listing age/duration from results.
[ ] Final brand/title cleared or changed. No trademark clearance has been done.
[ ] Owner creatively reviews product and approves AI disclosure, seller terms and final words.
[ ] Platform eligibility resolved. Etsy interpretation is open, not a proven yes or no. Payhip is a plausible alternative, not an approved shop.
[ ] Actual processor eligibility, fees, identity verification and payout route confirmed for owner's business location.
[ ] Local business/tax, buyer consumer rights, refund/support policy reviewed. Do not assume platform tax features cover the owner's obligations.
[ ] Actual shop support channel selected. Do not expose a personal address by accident.
[ ] Separate owner approval for signup, store/listing publication, price, posts and any spending.
[ ] Real end-to-end order/download test completed using an authorized route. Do not create fake sales/reviews.
[ ] Final source and deliverables backed up outside any publishing inbox; downloaded bytes verified.

## Family test sheet (copy once per group)
Do not collect names, children's photos, addresses or unnecessary personal details.
Group ID:
Date:
Age bands only:
Player count:
Paper size / printer settings / grayscale or color:
Setup time excluding printer runtime:
Play time:
Who read which role(s):
Job 1: solved? / hint number / unclear words / participant engagement:
Job 2:
Job 3:
Job 4:
Job 5:
Job 6:
Final dispatch:
Any external help from designer? If yes, what was needed?
Could the group finish using only supplied hints?
Did any player mostly watch?
Which instructions did the group reread?
Did the ending make sense and feel earned?
One thing they would change:
Would they choose another game like this? Why? Do not turn this answer into purchase proof.
Consent to use any feedback as a public quote must be asked separately. No quote permission is assumed.

## Stop rules
Any wrong/ambiguous answer or need for seller intervention blocks release. Repeated confusion on a step requires a rewrite and retest. Setup over 10 minutes excluding printing is a failure against the proposed low-setup target, not an excuse to advertise a faster time. Playtime outside the hypothesized 25-45 minute band may simply change the positioning; do not hide it. Do not launch because Christmas is approaching if these checks fail.

## Bounded low-touch plan (not scheduled)
One product, no personalization, no paid ads. Static instant delivery if the chosen platform supports it. Once separately approved and launched, review support and delivery failures daily. Track minutes spent, messages per order, refund causes, print issues and clue confusion. A ten-minute daily owner target and 90% automation are goals until measured. If support keeps exceeding the target, pause promotion and fix the underlying issue. No recurring monitoring has been started.

## Traffic test (only after a cleared launch)
Use the complete free sample as the first sharing asset. Do not spam groups or accounts. Publish only to owner-approved accounts/audiences and within their rules. Record qualified paid-page visits, sample downloads, paid orders, support minutes and refunds. Record the denominator and dates. A small number of visits or likes does not establish demand. Make a bounded decision with actual counts before building a second product. No traffic or sales test has been run.
