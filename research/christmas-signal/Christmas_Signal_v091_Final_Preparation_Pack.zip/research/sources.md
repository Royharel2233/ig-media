# Source ledger

## Source notes
[S1] Save Santa vendor product and dated buyer reviews, read 15 Nov 2026: https://www.printableescaperoom.com/listing/1110328019/save-santa-escape-room-game-christmas . Product specifications/price are vendor claims; review authenticity not independently authenticated.
[S2] The Escape Roomer, Santa is Missing review, 7 Dec 2023; complimentary copy disclosed: https://theescaperoomer.com/mystery-locks-santa-is-missing-review/ . Individual setup/play experience and narrative/checker friction.
[S3] The Escape Roomer, Monster Chest review, 26 Oct 2024; complimentary copy disclosed: https://theescaperoomer.com/mysterylocks-the-monster-chest-review/ . Individual setup, ink and variety observations.
[S4] MysteryLocks current Cozy Christmas product, fetched and inspected in browser 15 Nov 2026: https://mysterylocks.com/products/cozy-christmas-printable-escape-room . Current product positioning, specs and collection-wide review scope. No item sales estimate.
[S5] ESCAPETHEROOMers, Auntie's Manor review, 27 Mar 2022, updated 16 Oct 2025; complimentary copy disclosed: https://www.escapetheroomers.com/post/paper-adventures-the-case-of-auntie-s-manor . Family play, setup and low-ink detail. Page's unrelated spam comments were excluded.
[S6] Escape Kit, Stolen Jewels vendor page, read 15 Nov 2026: https://escape-kit.com/en/produit/case-stolen-jewels/ . Existing role-sharing proposition and setup claim.
[S7] Etsy Help, What Can I Sell, fetched and read live in browser 15 Nov 2026: https://help.etsy.com/hc/en-us/articles/360024112614-What-Can-I-Sell-on-Etsy?segment=selling . AI exclusions, disclosure and seller-input requirements.
[S8] Etsy Creativity Standards, last updated 10 Jun 2025, read live in browser 15 Nov 2026: https://www.etsy.com/legal/creativity . Differing level of detail from S7; classification unresolved.
[S9] Etsy digital listing rules, read 15 Nov 2026: https://help.etsy.com/hc/en-us/articles/115015628347-How-to-Manage-Your-Digital-Listings . At most five uploaded files, 20MB each; no digital variations. Four small customer PDFs fit the file-count/size limits, which does not settle product eligibility.
[S10] Payhip AI-product page, read 15 Nov 2026: https://payhip.com/sell-ai-products . Explicit AI-download support and automated delivery. Marketing copy, not sales proof or legal advice on copyright.
[S11] Payhip pricing, read 15 Nov 2026: https://payhip.com/pricing . $0/month plus 5% on free plan, processor fees extra. Local account fees remain unverified.
[S12] Payhip payment help, read 15 Nov 2026: https://help.payhip.com/article/64-connecting-your-paypal-account and https://help.payhip.com/article/173-how-do-i-get-paid . Processor connection required; country/account conditions. Do not apply generic fee examples to an Israeli account without checking.

Coverage limitation: evidence combines current vendor pages and vendor-hosted user reviews, independent specialist reviews with complimentary-copy disclosures, and official platform rules. It is not a representative customer survey or an item-level sales database. No competitor paid game was purchased or downloaded.
