# The Christmas Signal - complete preparation pack

v0.9.1 PLAYTEST CANDIDATE. Not a shop launch or a commercially validated release.

Start with customer/01_Game_A4.pdf (or USLetter) for the game and research/Research_and_Product_Decisions.pdf for evidence and choices. The four customer PDFs plus readme are the proposed buyer download set AFTER release approval. seller/ contains free samples, five real-PDF-preview listing image drafts, copy, promotion concepts, FAQ, support drafts and a release/playtest checklist. research/ contains the sourced decision brief. source/ contains editable Python/content sources and the font licence. qa/ separates logic checks from unperformed human testing.

Nothing has been published to a shop, no account created, no spending approved. Customer files contain no personal user context. Working imprint Letterlight Dispatch is provisional, not trademark-cleared. Etsy policy applicability is unresolved; Payhip is a plausible alternative requiring owner/account verification, not a selected live store.

Sources use system Noto Sans/Serif fonts (SIL OFL licence included), ReportLab, Pillow and PyMuPDF. No paid assets, competitor artwork or paid competitor files are included. All diagrams are original vector drawings. Regeneration commands: python source/build_game.py; python source/test_logic.py; python source/package_assets.py. Build scripts are not customer files.
