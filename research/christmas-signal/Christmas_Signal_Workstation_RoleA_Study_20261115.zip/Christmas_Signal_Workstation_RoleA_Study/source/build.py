from pathlib import Path
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.pagesizes import A4,letter
from reportlab.lib.colors import HexColor
from reportlab.platypus import Paragraph
from reportlab.lib.styles import ParagraphStyle
from PIL import Image
import pymupdf as fitz
R=Path(__file__).resolve().parents[1]
for n,p in [('Body','NotoSans-Regular.ttf'),('Bold','NotoSans-Bold.ttf'),('Display','NotoSerif-Bold.ttf')]:pdfmetrics.registerFont(TTFont(n,'/usr/share/fonts/truetype/noto/'+p))
INK='#273c43';BLUE='#185c7f';RED='#9b312a';GREEN='#24624b'
def build(path,size):
 w,h=size;aw=500;ah=750;x=(w-aw)/2;top=12;c=canvas.Canvas(str(path),pagesize=size)
 c.setTitle('The Christmas Signal | Sorting workstation | Role A design study');c.setAuthor('Letterlight Dispatch')
 c.drawImage(str(R/'art/Workstation.png'),x,h-top-ah,width=aw,height=ah)
 def text(xx,t,s,sz=10,font='Body',col=INK):c.setFillColor(HexColor(col));c.setFont(font,sz);c.drawString(x+xx,h-top-t-sz*.83,s)
 def center(t,s,sz=10,font='Body',col=INK):text((aw-pdfmetrics.stringWidth(s,font,sz))/2,t,s,sz,font,col)
 def para(xx,t,s,width=365,sz=10,lead=14):
  p=Paragraph(s,ParagraphStyle('p',fontName='Body',fontSize=sz,leading=lead,textColor=HexColor(INK)));_,ph=p.wrap(width,400);p.drawOn(c,x+xx,h-top-t-ph);return ph
 def line(xx,t,xx2,t2,col='#a9aa9b'):
  c.setStrokeColor(HexColor(col));c.setLineWidth(.5);c.line(x+xx,h-top-t,x+xx2,h-top-t2)
 center(44,'THE CHRISTMAS SIGNAL',8.5,'Bold',RED)
 center(57,'The route keeper',21,'Display',BLUE)
 center(79,'ROLE A  /  Share your clues with your partners.',9,'Bold',BLUE)
 # Route parchment: keep all functional data clear of decorative pin/clip.
 text(86,126,'1  FIND THE ROUTE',13,'Bold',BLUE);text(325,129,'WITH B',9,'Bold',BLUE)
 para(86,147,'Map: north is up. Columns A-D; rows 1-4.',width=335,sz=9.7,lead=13)
 gx=125;gy=181;cell=18
 for j,k in enumerate('ABCD'):text(gx+j*cell+(cell-pdfmetrics.stringWidth(k,'Bold',9))/2,gy-14,k,9,'Bold',BLUE)
 grid=[list('KFMR'),list('PAIS'),list('TENO'),list('DGWL')]
 for i,row in enumerate(grid):
  text(gx-16,gy+i*cell+4,str(i+1),9,'Bold',BLUE)
  for j,k in enumerate(row):
   c.setFillColor(HexColor('#fffdf3'));c.setStrokeColor(HexColor('#406c7d'));c.setLineWidth(.6);c.rect(x+gx+j*cell,h-top-gy-(i+1)*cell,cell,cell,stroke=1,fill=1)
   text(gx+j*cell+(cell-pdfmetrics.stringWidth(k,'Bold',10))/2,gy+i*cell+4,k,10,'Bold')
 para(255,182,'The depot is A4.<br/>Start on its D.<br/>Do not record D.<br/>B holds the route.',width=155,sz=10,lead=16)
 # Tally clipboard.
 text(103,312,'3  BALANCE THE MAIL',13,'Bold',GREEN);text(367,315,'WITH C',9,'Bold',GREEN)
 para(103,336,'Each item always has the same whole-number weight. C has the label key and reading order.',width=300,sz=10,lead=14)
 for i,eq in enumerate(['MITTEN + BELL = 9','BELL + STAR = 7','STAR + MITTEN = 8','ENVELOPE + STAR = 5']):
  yy=377+i*14;text(117,yy,eq,10.2,'Bold',GREEN)
 # Delivery ledger.
 text(89,488,'5  DELIVER THE PARCELS',13,'Bold',RED);text(367,491,'WITH D',9,'Bold',RED)
 para(89,512,'Three residents. Three homes. Three gifts. Each person has exactly one home and one gift; nothing repeats. D holds four witness clues.',width=320,sz=10,lead=14)
 for i,(lab,v) in enumerate([('Residents:','Ari  /  Bea  /  Cal'),('Homes:','Bakery  /  Orchard  /  Tower'),('Gifts:','STAR  /  BELL  /  DRUM')]):
  yy=570+i*22;text(89,yy,lab,10,'Bold',RED);text(160,yy,v,10,'Bold');line(89,yy+16,404,yy+16)
 # Status is outside the actual play artifacts and remains readable.
 c.setFillColor(HexColor('#ffffff'));c.rect(x,14,500,17,fill=1,stroke=0)
 c.setFont('Bold',7.5);c.setFillColor(HexColor(INK));c.drawCentredString(w/2,20,'ONE DESIGN STUDY / Use with v0.9.1 ledger + roles B-D / Border art is not a clue')
 c.showPage();c.save()
if __name__=='__main__':
 for lab,size in [('A4',A4),('USLetter',letter)]:
  p=R/f'Role_A_Workstation_{lab}.pdf';build(p,size);d=fitz.open(p);d[0].get_pixmap(matrix=fitz.Matrix(2,2),alpha=False).save(R/'renders'/f'{lab}.png')
 im=Image.open(R/'renders/A4.png');im.thumbnail((760,1080));im.save(R/'Role_A_Workstation_Preview.jpg',quality=96)
 Image.open(R/'renders/A4.png').convert('L').save(R/'renders/Grayscale.png')
