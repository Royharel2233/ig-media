# Sorting workstation: one interior design study
15 November 2026. The Christmas Signal. ONE alternate role-A sheet for visual approval, not a complete new edition.

The approved playful cover/world is retained. The prior worksheet-with-mascot interior is discarded. This alternative makes the page a postal sorting workstation: a route parchment pinned on cork, a weigh-station tally clipboard and an open delivery ledger. The entire background is original AI-assisted illustration; real clues are separately typeset selectable text and a precisely drawn grid. Decorative border art is explicitly not a clue.

Role-A jobs 1, 3 and 5 retain the v0.9.1 clue content: identical map letters/coordinates, starting note, four balance equations, item rule, resident/home/gift lists and partner links. Use this sheet with the existing ledger and roles B-D. The complete existing game has not been restyled or changed.

This version is intentionally color-rich and ink-heavy. It is NOT a low-ink replacement or proof that customers prefer it. The artwork is inset on both A4 and US Letter, so borderless printing is not required. Author inspected actual color and grayscale renders and checked required clue text programmatically. Digital grayscale inspection is not a home-printer test. No real family test, age/duration validation, conversion/demand result or marketplace clearance is added.

Independent-review status is supplied separately with delivery. Do not treat a visual study as full-kit approval, a completed launch or a print-tested commercial release. Working imprint and all previous release gates remain open. No shop/listing/account/spending action occurred.

Included: actual A4 and US Letter PDFs; preview and full color/grayscale renders; original background artwork; editable ReportLab source; clue-preservation check results; Noto font licence. No competitor assets or private customer/account facts. If the direction is approved, extend carefully one page at a time with equivalent clue/logic/layout checks before replacing the complete kit.
