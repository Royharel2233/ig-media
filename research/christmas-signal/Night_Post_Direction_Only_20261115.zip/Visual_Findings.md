# Visual market check, 15 November 2026

## Verdict
The delivered hero is too restrained and generic for the intended family-Christmas-adventure position. It is readable, honest and not visually broken, but the comparison makes it look more like a worksheet product or report than a festive game. "AI slop" is a subjective reaction, not a verifiable production diagnosis. A clean layout does not by itself establish desirable product design. Do not infer competitors' AI usage from their images.

## What was actually inspected
Three images downloaded from the competitors' current product pages and inspected as pixels, plus the actual delivered v0.9.1 listing hero. No claim of sales/conversion measurement. This is a bounded visual comparison, not a new demand study.

1. Save Santa vendor hero: the title fills much of the square, strong red/green/gold contrast, a dense festive scene and recognizable puzzle/prop cues. It signals Christmas and adventure before one reads the details. Its richness also risks clutter. Do not copy this layout or add unrelated props that are absent from our kit.
Product: https://www.printableescaperoom.com/listing/1110328019/save-santa-escape-room-game-christmas
Observed image: https://i.etsystatic.com/26702288/r/il/1cad36/8432921463/il_fullxfull.8432921463_9k4h.jpg

2. Escape Kit, Stolen Jewels cover: one illustrated train world with characters and a clear central title plate. The image tells the buyer what sort of experience it is, rather than showing a generic document. It is not proof that character art is required or that this cover converts well.
Product: https://escape-kit.com/en/produit/case-stolen-jewels/
Observed image: https://escape-kit.com/wp-content/uploads/2025/06/banner-the-case-of-the-stolen-jewels-family-escape-room-600x600.png

3. MysteryLocks Cozy Christmas: the detail image shows the same village palette, typography and decorative world across actual game materials, not just a decorative listing cover. There is visible variation in the components. Our no-cut/low-ink goal should not imitate their cut-out components, but consistency and world-building matter inside too.
Product: https://mysterylocks.com/products/cozy-christmas-printable-escape-room
Observed image: https://mysterylocks.com/cdn/shop/files/il_fullxfull.8738812333_5exe.jpg?v=1793095113&width=750

4. Our delivered hero: large neutral field, small full-page PDF preview, fine rules, long feature list, modest title hierarchy and almost no visual story. At thumbnail size the actual game page becomes tiny gray texture. It advertises orderly paperwork better than an adventure. Internal pages are consistent but too repetitive in rectangular-panel treatment.

## One direction to approve before a full redesign
"Night Post": a flat, deliberately drawn postal-adventure identity. Deep winter blue, warm ivory, muted postal red and lantern gold. One original tower-and-letter illustration, a title readable at thumbnail size, and short literal product/benefit wording. Use the envelope, route marks, postal stamp and lantern as a small repeated visual language, not random decorative ornaments. No photoreal props or invented photographs. Working imprint is unchanged and still not cleared.

One cover-direction image is prepared, not a new commercial release. Existing game/answers/source are unchanged. It is a direction study, not evidence of better conversion and not a promise that a new cover alone fixes the product.

If approved, carry the system to one role-sheet sample first: larger role-specific stamps, clearer paired-job labels, small purposeful vignettes, stronger hierarchy and more varied compositions while preserving the exact puzzle content. Keep white/low-ink printable interiors and optional color cover; a dark listing hero does not mean printing dark full-bleed pages. Preserve all answer data and independent QA. Recheck one sample before applying across the pack. No full redesign, listing or publication is authorized by this comparison.

## Do not claim
- that the current design is commercially competitive merely because it passes layout QA;
- that this visual sample proves demand or conversion;
- that rich competitor images are human-made or AI-generated without provenance;
- that role-based play or a postal theme creates a protected moat;
- that the entire product was redesigned or human-tested.

Third-party images are evidence for private visual review only, not product art or assets to put into a public product/source backup. The original cover study has its own separate source and may be backed up without competitor images.
