from PIL import Image,ImageDraw,ImageFont,ImageOps
from pathlib import Path
import math
R=Path('/downloads/design-review')
regular='/usr/share/fonts/truetype/noto/NotoSans-Regular.ttf';bold='/usr/share/fonts/truetype/noto/NotoSans-Bold.ttf';serif='/usr/share/fonts/truetype/noto/NotoSerif-Regular.ttf'
def f(s,b=False,ser=False):return ImageFont.truetype(serif if ser else bold if b else regular,s)
# One original cover-direction study, not a playable revision or photoreal mockup.
im=Image.new('RGB',(1500,1500),'#112d3b');d=ImageDraw.Draw(im)
cream='#fff8e8';gold='#edbd63';red='#bd453b';blue='#294c5b'
# Ticket edge and stamp-like frame.
d.rectangle((35,35,1465,1465),outline=gold,width=3)
d.text((85,65),'LETTERLIGHT DISPATCH',font=f(24,True),fill=gold)
d.text((85,125),'THE CHRISTMAS',font=f(85,True),fill=cream)
d.text((79,218),'SIGNAL',font=f(180,True),fill=cream)
d.text((87,445),'One last letter. Nobody solves it alone.',font=f(35,ser=True),fill=gold)
d.text((88,507),'PRINTABLE COOPERATIVE PUZZLE ADVENTURE',font=f(25,True),fill=cream)
# Original graphic village / signal tower. No borrowed art or generative photos.
for x,y,r in [(1010,560,5),(1350,505,4),(125,606,4),(670,585,5),(1200,660,3),(1420,704,3),(790,760,3),(195,760,3)]:d.ellipse((x-r,y-r,x+r,y+r),fill=cream)
# Beam first, then tower silhouette.
d.polygon([(1050,720),(1440,560),(1440,780)],fill=blue)
d.polygon([(960,720),(600,560),(600,780)],fill=blue)
# Rolling snow and neighborhood.
d.ellipse((-250,1030,1900,1600),fill='#e4e9df')
for x,y,w,h in [(100,1020,140,180),(266,990,170,220),(455,1070,120,150),(1190,1025,160,180),(1360,1070,110,140)]:
 d.rectangle((x,y,x+w,y+h),fill=blue);d.polygon([(x-12,y),(x+w//2,y-55),(x+w+12,y)],fill=red)
 for wx in [x+24,x+w-48]:d.rectangle((wx,y+45,wx+22,y+78),fill=gold)
# Tower, roof, lantern.
d.polygon([(905,1160),(930,752),(1090,752),(1115,1160)],fill='#234755')
d.rectangle((908,674,1113,775),fill=gold);d.rectangle((936,691,1084,752),fill='#ffe4a2')
for xx in [947,1008,1067]:d.line((xx,684,xx,765),fill='#234755',width=8)
d.polygon([(878,675),(1010,555),(1143,675)],fill=red)
d.line((1010,555,1010,520),fill=gold,width=4)
d.ellipse((1000,507,1020,527),fill=gold)
d.rectangle((981,1045,1039,1160),fill='#102e3a')
# Letter is the focus in foreground, with paired clue seal.
d.rounded_rectangle((145,865,780,1230),radius=8,fill=cream)
d.polygon([(145,865),(460,1080),(780,865)],outline=red,width=6)
d.line((145,1230,358,1050),fill=red,width=4);d.line((780,1230,568,1050),fill=red,width=4)
d.ellipse((401,1025,524,1148),fill=red)
pts=[]
for j in range(10):
 a=-math.pi/2+j*math.pi/5;r=34 if j%2==0 else 15;pts.append((462+math.cos(a)*r,1086+math.sin(a)*r))
d.polygon(pts,fill=cream)
# Familiar postal geometry, not random decorative icons.
d.rounded_rectangle((90,1290,1410,1388),radius=8,fill=cream)
labels=['4 SHARED ROLES','6 JOBS + FINALE','NO CUTTING']
for i,t in enumerate(labels):
 x=120+i*440;d.text((x,1320),t,font=f(28,True),fill='#112d3b')
 if i<2:d.line((x+405,1310,x+405,1367),fill='#c0b89f',width=2)
d.text((88,1418),'COVER DIRECTION ONLY  /  NOT A PRODUCT REVISION  /  NO CONVERSION TEST',font=f(20,True),fill='#112d3b')
im.save(R/'One_Direction_Night_Post.jpg',quality=95)
