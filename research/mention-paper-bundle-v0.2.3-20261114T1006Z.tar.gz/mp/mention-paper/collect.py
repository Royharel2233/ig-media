"""Prospective snapshot collector. Each run writes a NEW generation file
data/snapshots/<UTC stamp>.jsonl (never appended to or overwritten) and one log line to data/logs/collect_log.jsonl.
Only OPEN markets with a usable end time are recorded, so a row cannot contain a price that already reflects the
outcome. Each row has fetched_at (UTC). Markets that closed before our first look are never captured (by design:
this is prospective). Run: python3 collect.py"""
import json, os, glob
from common import *

def gamma_events():
    out, off = [], 0
    while True:
        d = get_json(f"{GAMMA}/events?tag_slug=mention-markets&closed=false&limit=50&offset={off}")
        if not d: break
        out += d
        if len(d) < 50: break
        off += 50
    return out

def main():
    t = now_utc(); fetched = iso(t)
    rows = []
    log = {"fetched_at": fetched, "events_listed": 0, "events_skipped_past_end": 0, "events_null_end": 0,
           "parrot_brief_failed": [], "markets_open": 0, "markets_matched_parrot": 0, "unmatched_words": [],
           "no_qualifying_skipped": 0, "p_src_counts": {}, "fetch_failures": []}
    prev_end = {}
    for p in sorted(glob.glob(f"{DATA}/snapshots/*.jsonl")):
        for l in open(p):
            r0 = json.loads(l); prev_end[r0["event_slug"]] = r0["event_end"]
    log["event_end_changes"] = []
    evs = gamma_events()
    if not evs:
        log["error"] = "no gamma events returned"
    log["events_listed"] = len(evs)
    for ev in evs:
        slug, end = ev["slug"], ev.get("endDate")
        if slug in prev_end and end and prev_end[slug] != end:
            log["event_end_changes"].append([slug, prev_end[slug], end])
        if not end:
            log["events_null_end"] += 1; continue
        if parse_iso(end) < t:
            log["events_skipped_past_end"] += 1; continue
        br = get_json(f"{PARROT}/brief?event=p:{slug}&limit=0&format=json")
        prow, as_of = {}, None
        if br:
            as_of = br["meta"].get("as_of")
            for r in table(br): prow[norm(r["w"])] = r
        else:
            log["parrot_brief_failed"].append(slug)
        for m in ev["markets"]:
            if m.get("closed"): continue
            title = m.get("groupItemTitle") or ""
            if title.startswith("-No Qualifying"):
                log["no_qualifying_skipped"] += 1; continue
            pr = prow.get(norm(title))
            log["markets_open"] += 1
            if pr: log["markets_matched_parrot"] += 1
            else: log["unmatched_words"].append(f"{slug}|{title}")
            if pr:
                k = pr.get("p_src") or "none"; log["p_src_counts"][k] = log["p_src_counts"].get(k, 0) + 1
            rows.append({
                "fetched_at": fetched, "event_slug": slug, "event_title": ev.get("title"), "event_end": end,
                "market_id": m.get("id"), "condition_id": m.get("conditionId"), "word": title,
                "bid": f(m.get("bestBid")), "ask": f(m.get("bestAsk")), "last": f(m.get("lastTradePrice")),
                "volume": f(m.get("volumeNum")),
                "parrot_p": f(pr.get("p")) if pr else None, "parrot_p_src": pr.get("p_src") if pr else None,
                "parrot_n": pr.get("n") if pr else None, "parrot_y": pr.get("y") if pr else None,
                "parrot_as_of": as_of})
    log["fetch_failures"] = [list(x) for x in FAILS][:50]
    os.makedirs(f"{DATA}/snapshots", exist_ok=True); os.makedirs(f"{DATA}/logs", exist_ok=True)
    path = f"{DATA}/snapshots/{t.strftime('%Y-%m-%dT%H%M%SZ')}.jsonl"
    if rows:
        with open(path, "x") as fh:
            for r in rows: fh.write(json.dumps(r, sort_keys=True) + "\n")
    log["rows_written"] = len(rows); log["file"] = os.path.basename(path) if rows else None
    with open(f"{DATA}/logs/collect_log.jsonl", "a") as fh: fh.write(json.dumps(log, sort_keys=True) + "\n")
    print(json.dumps({k: v for k, v in log.items() if k not in ("unmatched_words",)}))
    if log["unmatched_words"]: print("unmatched:", log["unmatched_words"][:10])

if __name__ == "__main__":
    main()
