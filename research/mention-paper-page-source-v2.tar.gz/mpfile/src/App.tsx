import React from 'react';
import { Callout, Closing, Facts, FileCard, Group, Header, NumberedList, Paragraph, Photos, Row, Rows, Text, TextLink } from '@instinct/files';
import hero from './photos/hero.png';
import './style.css';

const REPO = 'https://github.com/Royharel2233/ig-media';

export function App() {
    return <FileCard>
        <div dir="rtl" lang="he" className="he">
            <Header title="כלי נייר לתחזיות מילים בפולימרקט" fact="אבטיפוס עובד, בלי מסחר. עדיין אין תוצאה על יתרון." intro="בניתי כלי מקומי וחינמי שבודק אם אפשר לחזות מילים ש-X יגיד, ושומר יומן חי להשוואה למחיר השוק. הוא לא מבצע עסקאות, לא נוגע בארנק ולא משתמש ב-API בתשלום." />
            <Photos label="איור להמחשה בלבד" items={[{ src: hero, alt: 'איור מופשט של בועות דיבור וקו גרף' }]} />

            <Group label="מה נבנה" heading>
                <Rows>
                    <Row number={1} name="בדיקה היסטורית" detail="נתוני הסגירה החופשיים של Parrot למילים של טראמפ בפולימרקט. כל שאלה נחזית רק ממה שהיה ידוע לפני תאריכה. אין שם מחירי שוק." />
                    <Row number={2} name="יומן חי" detail="כל 6 שעות נשמר צילום של מחירי פולימרקט ושל Parrot לשווקים פתוחים. בהמשך זה מושווה לתוצאה בפועל, בלי הסתכלות לעתיד." />
                    <Row number={3} name="דוח עם מסחר על הנייר" detail="קנייה של מניה אחת במחיר הטוב ביותר, עם עמלת 0.04×p×(1-p). זה אופטימי, כי לא מחשבים עומק הספר והחלקת מחיר." />
                </Rows>
            </Group>

            <Group label="תוצאות עד עכשיו" heading>
                <Facts items={[
                    { label: 'היסטורי', value: '677 שאלות (2024-08 עד 2026-10), 647 נבחנו' },
                    { label: 'Brier, שיעור קבוע', value: '0.2446' },
                    { label: 'Brier, שיעור לפי מילה', value: '0.222 (נמוך יותר טוב יותר)' },
                    { label: 'יומן חי', value: '350 שורות, 175 שווקים, שני צילומים' },
                    { label: 'נסגרו וניתנים לבחינה', value: '0 (resolved-with-snapshots)' },
                ]} />
                <Callout title="מה זה לא מוכיח" tone="warning">
                    ההיסטורי הוא על שיעורי בסיס בלבד ובלי מחירים, ולכן לא אומר כלום על ניצחון על השוק או על רווח. 57 שווקים שנסגרו לפני שהתחלנו לצלם נמצאים במטמון התוצאות, אך אין להם צילום ולכן אינם נספרים. גם מאה או מאתיים שווקים לא יוכיחו יתרון, כי שווקים בתוך אותו אירוע תלויים זה בזה.
                </Callout>
            </Group>

            <Group label="מה עוד חסר" heading>
                <Paragraph>שכבת ה-LLM לא נבנתה. לא אימתנו מכסה חינמית של מודל מתארח, ולא נבדק מודל מקומי. לכן זו לא הארכיטקטורה המלאה שהצעת, אלא הבסיס שמודד אותה. ה-0.7/0.3 בכלי הוא ערבוב של מחיר השוק עם שיעור בסיס, לא MixMCP.</Paragraph>
                <NumberedList items={[
                    'שבועות של צילומים עד שיהיו מאות שווקים שנסגרו עם צילום.',
                    'בדיקת עומק הספר ועמלות אמיתיים לפני כל טענה על רווח ניתן לביצוע.',
                    'מודל תחזית ללא תשלום, אם יימצא כזה שאפשרי להריץ.',
                ]} />
            </Group>

            <Group label="הנחות שנקבעו מראש" heading>
                <Paragraph>סף ספרד של 0.30 וגיל צילום מרבי של 12 שעות הם בחירות שרירותיות לפיילוט ולא ערכים מכוילים. הדוח מציג בנפרד טבלת רגישות קבועה (6/12/24 שעות מול 0.15/0.30/0.50), רק לדיווח, ולא כדי לבחור הגדרה. תחזית Parrot שמקורה לא ידוע, או שהיא רק שיעור-קדם, מקבלת קבוצה נפרדת ולא נכנס לתוצאה הראשית.</Paragraph>
            </Group>

            <Group label="חבילת המקור והשחזור" heading>
                <Paragraph>חבילת הקוד, הנתונים והיומנים שמורה בגיטהאב שלך. כדי לשחזר: מורידים את הארכיון האחרון, פותחים, ומריצים <code dir="ltr">run_wake.sh</code>. אין מפתחות או נתונים פרטיים בארכיון.</Paragraph>
                <Rows>
                    <Row name="גרסה 0.2.1, העדכנית" detail={<span className="ltr" dir="ltr">research/mention-paper-prototype-v0.2.1.tar.gz<br />sha256 b9dd1c72c19e236e3cfd5d342c0de15a7185c6215f0520dd3c5b0eee3f4cbcf4</span>} />
                    <Row name="גרסאות קודמות נשמרות" detail={<span className="ltr" dir="ltr">research/mention-paper-prototype-v0.2.tar.gz<br />research/mention-paper-prototype-2026-10-25.tar.gz</span>} />
                </Rows>
                <Text>
                    <Paragraph><TextLink href={`${REPO}/commit/8949015bf19e9d7777a0056f15d4f6c32ac22fcc`}>הקומיט של גרסה 0.2.1</TextLink></Paragraph>
                    <Paragraph><TextLink href={`${REPO}/commit/8911b416b9a38cfb41b9a5803b65d583889bccc1`}>הקומיט של גרסה 0.2</TextLink></Paragraph>
                    <Paragraph><TextLink href="https://parrot.markets/api-guide">מקור הנתונים: אתר Parrot (רישיון CC BY 4.0)</TextLink></Paragraph>
                </Text>
                <Callout title="איסוף שוטף וגיבוי" tone="note">האיסוף רץ כל 6 שעות מול ממשקים ציבוריים בלבד, עם הפסקות בין קריאות. הגיבוי לגיטהאב נעשה בנפרד; מאז הגיבוי האחרון ייתכנו נתונים ששמורים רק מקומית. אין חשבון מחובר ואין שליחה לשום מקום.</Callout>
            </Group>

            <Closing>נבדק ב-25.10.2026. לא בוצעה שום עסקה והמידע אינו ייעוץ השקעות.</Closing>
        </div>
    </FileCard>;
}
