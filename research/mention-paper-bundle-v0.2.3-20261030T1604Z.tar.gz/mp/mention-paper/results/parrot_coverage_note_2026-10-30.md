# Parrot coverage note (written 2026-10-30, read-only diagnosis)

Observed:
- Collector log: every Polymarket event matched Parrot through the 2026-10-29T04:03Z snapshot (non-earnings events such as Trump rallies, weekly/monthly, MrBeast, UK PMQs included). From the 2026-10-29T10:03Z snapshot on, Parrot brief calls for those events return 404 {"error":"not_found","detail":"unknown event 'p:<slug>'"}; matched 13 of 129 open markets (13 of 135 at 22:03Z). Earnings events (e.g. Amazon Oct 29) still match.
- Parrot /api/v1/events (checked 2026-10-30 ~00:04 IST): 135 events = 134 Kalshi earnings + 1 Polymarket earnings; all call_type=earnings. Parrot /llms.txt describes its scope as earnings-call mention markets.
- Historical loss window: between the 04:03Z and 10:03Z snapshots on 2026-10-29. Rows before that keep their Parrot p; rows after have none for non-earnings events. No snapshot was rewritten.

Inferred (not announced, no changelog found): Parrot narrowed its catalog to earnings calls. Cause and permanence are unconfirmed.

Handling (unchanged collection): keep logging all Polymarket markets; non-earnings events are market-only from 10:03Z on; prospective Parrot/blend scoring effectively covers earnings calls (and earlier-frozen non-earnings events). The original rally/speech question is not testable with current Parrot coverage; other data sources were not evaluated. No transcript model built, no scoring change.
