# Source ledger - Polymarket mention-market feasibility (2026-10-25)

| Source | URL | Type | Used for |
| --- | --- | --- | --- |
| arXiv 2602.21229v2 (LinqAlpha/MIT et al., Feb 2026) | https://arxiv.org/html/2602.21229v2 | preprint | MixMCP definition; measured edge vs market (Brier 0.1392 vs 0.1402, acc 80.3 vs 79.8, N=856 Kalshi earnings-call markets); no trading sim |
| parrot.markets methodology | https://parrot.markets/methodology | primary data service | component-1 commoditized; 97.89% settlement agreement; "an hour before an event, history added nothing measurable to the price" |
| parrot.markets accuracy | https://parrot.markets/accuracy | primary data service | walk-forward Brier 0.206 vs 0.247 constant on ~40.3K markets; per-category table |
| parrot.markets API + agents | https://parrot.markets/api-guide , /agents | primary | free REST + MCP server, no key |
| Polymarket fees doc | https://docs.polymarket.com/trading/fees | vendor docs | Mentions taker feeRate 0.04, fee=C*0.04*p*(1-p); maker 0 + 25% rebate |
| Polymarket gamma API event 1242924 | https://gamma-api.polymarket.com/events/1242924 | live primary | Michigan rally 26.10: $14K vol / 20 words; per-word $10-$2.5K; spreads 3-51c |
| Polymarket Event Mentions Contract PDF | https://polymarket-upload.s3.us-east-2.amazonaws.com/market_products/Mentions/Event+Mentions+Contract+DeFi.pdf | vendor rules | resolution mechanics: plurals/possessives count, derivations don't, homonyms yes, homophones no; source = event audio/video |
| NPR 2026-08-13 | https://www.npr.org/2026/08/13/nx-s1-5930689/cftc-probe-mention-markets-prediction-markets-kalshi | news | CFTC probe; teleprompter-operator insider case; Kalshi pulled sports mentions; Polymarket mentions offshore-only |
| Lightning Rod models + docs | https://www.lightningrod.ai/models , https://docs.lightningrod.ai/ | vendor | "Foresight" = foresight-v4, paid ($6/1M output tokens), OpenAI-compatible |
| Tyrael interviews | https://pickscribe.com/v/ePT6aMqk2Oo , https://www.youtube.com/watch?v=brAukxAt2Ls | practitioner anecdote | ~$99.5K profit; full-time; transcripts + real-time news weighting; live-event fills |
| PR&R idiolect strategy | https://www.polyresearchrobotics.com/strategies/speaker-idiolect-frequency-model | vendor strategy db | Roy's component 1 described as a sold strategy (labeled vendor) |
| Kalshi help | https://help.kalshi.com/en/articles/14026044 | vendor docs | international availability "many countries", subject to member agreement |
| Polymarket CLOB book API | https://clob.polymarket.com/book?token_id=... | live primary | depth at best quotes: Marxist ask 20 sh, Russia/Ukraine 50/50, China 200/550 (fetched 2026-10-25) |
