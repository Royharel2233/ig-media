# Feasibility: Polymarket mention-market prediction engine (working research doc, 2026-10-25)

Roy's proposed architecture:
1. Transcript corpus per speaker x event type; per-word occurrence rates.
2. General LLM (or "Foresight" API) updating the market price with the week's news, "MixMCP" method.
3. Liquidity + bid/ask filter, because thin books eat theoretical edge.

## Bottom line (REVISED after review)

The architecture is real and technically plausible, and partially validated academically - but a NET
TRADING EDGE IS UNPROVEN. The measured forecast improvement (Brier 0.1402 -> 0.1392, accuracy +0.5pp on
856 Kalshi earnings-call markets) is a scoring-rule gain, not a per-market probability edge in cents, and
cannot be directly compared to spreads. Separately, observed costs are high: wide spreads (3-51c) and
shallow depth (tens to low-hundreds of dollars at best quotes) on Polymarket word books. Whether any
model edge beats those costs has never been measured - by the paper (no trading simulation) or anyone
else in the sources found. No evidence-based money recommendation. Feasible as a low-cost paper
experiment only.

## Term verification
- "MixMCP": arXiv:2602.21229v2 "Forecasting Future Language: Context Design for Mention Markets"
  (LinqAlpha, MIT, Kalshi-affiliated authors; dataset Apr-Dec 2025). MCP = Market-Conditioned Prompting:
  give the LLM the market probability as a prior plus transcripts+news, ask for a revised probability.
  MixMCP = 0.7*market + 0.3*MCP (alpha tuned on held-out split). Exactly Roy's component 2.
- "Foresight": Lightning Rod (lightningrod.ai) foresight-v4 model, OpenAI-compatible API returning
  calibrated probabilities. PAID: $6/1M output tokens; API key; MPP top-up from $1. Not required for
  MixMCP - the paper used a general LLM (GPT-5.1) with the MCP prompt.

## The measured edge (arXiv:2602.21229)
- N=856 Kalshi earnings-call mention markets, 50 companies, 70 events; cutoff 7 days pre-call; GPT-5.1.
- Market baseline: Brier 0.1402, ECE 0.0651, accuracy 79.8%.
- MixMCP: Brier 0.1392, ECE 0.0666, accuracy 80.3%. (+0.5pp accuracy, 0.001 Brier)
- MCP alone (no mixture) is WORSE than the market (Brier 0.1470, acc 78.2%).
- Only 8.2% of instances have binary disagreement with the market; MCP's wins concentrate at
  mid-confidence (50-60%: wins 17/30; 60-70%: 5/8).
- No trading simulation, no fees/slippage in the paper. No evidence the 0.001 Brier survives costs.

## Component 1 already exists, free: parrot.markets
- Free open data for Kalshi+Polymarket mention markets: transcripts, word history under each venue's
  exact settlement rules, calibrated base-rate probabilities, settlement QA.
- Word counts agree with venue settlement on 97.89% of 19,585 settled markets (all mismatches public).
- Walk-forward test, 40,281-40,338 settled markets since May 1 2026: base-rate p Brier 0.206 vs 0.247
  constant. BUT: "Market prices are usually sharper. An hour before an event, history added nothing
  measurable to the price. Use p as context, not as a signal." White House category barely beats constant.
- Free REST API + free MCP server (no key/OAuth), CC-BY data, llms.txt for agents.
- ~5,400 mention events listed by Kalshi+Polymarket since mid-2024.

## Component 3 confirmed by live Polymarket data (gamma API, 2026-10-25)
Event "What will Trump say during his Midterm Rally in Michigan?" (Oct 26 2026, event id 1242924):
- Total event volume $13,965 across 20 word markets; per-word volume $10-$2,492 (median ~$450).
- Spreads 3-51 cents, median ~14 cents (gamma bestBid/bestAsk snapshot). CLOB book depth fetched for
  3 markets confirms gamma quotes are live best quotes (China moved 0.42->0.41 bid between calls) but
  depth at best levels is small: Marxist best ask 20 shares (~$14), Russia/Ukraine 50/50 shares,
  China 200 bid / 550 ask. Round-trip vs one-way: holding to resolution pays spread once + taker fee;
  trading in/out pays it twice.
- Resolution source: audio/video of the event (not an official transcript). Full rules: Event Mentions
  Contract PDF - plurals/possessives count, derivations don't ("running" != "run"), homonyms count,
  homophones don't, expanded acronyms don't count ("artificial intelligence" != "AI").
- Volume varies wildly: election-season rallies $1.29M (Oct 2024), Apr 2026 news conf $503K,
  current midterm rallies $14-79K, "Trump this week" weekly ~$6K.
- Fees (docs.polymarket.com/trading/fees): Mentions taker feeRate 0.04, fee = C*0.04*p*(1-p)
  (max ~1c/share at 50c). Makers pay 0 and share 25% of taker fees as rebates.
  -> Taker needs roughly 5-15c of true mispricing to break even vs a measured model edge of ~0.5pp.

## Practitioner reality (Tyrael, #1 mentions trader, interviews)
- ~$99.5K profit run, full-time, mostly Kalshi mentions now (deeper liquidity there); plays Trump
  rallies + sports announcer markets.
- Method: transcript data + heavy current-events weighting ("earnings calls ~70% data/30% news";
  political events are news-driven - Venezuela-bombing example where breaking news overrode base rates).
- Watches events live for fills; niche selection; fair-value sizing. Not passive, not 10 min/day.

## Structural risks
- Insider/manipulation risk is documented: NPR 2026-08-13 - CFTC probing mention markets; Trump's
  longtime teleprompter operator caught trading Kalshi word markets (Kalshi surveillance flagged it);
  Kalshi removed sports mention markets "until further notice". Makers/resting orders are exposed to
  adverse selection from people with non-public speech info and live-ASR bots.
- Regulatory: Polymarket lists mention markets only on its offshore (non-CFTC) site; category may shrink.
- Timing mismatch: Roy's weekly update cadence vs per-event markets that resolve within hours. Edge
  windows: right after market creation (thinnest liquidity) or live during the event (speed game).
- Variance: binary outcomes; ~60-100 usable word bets/month at current liquidity; months of paper
  tracking needed to separate edge from luck.

## What a zero-cost validation would look like (research only)
- parrot.markets free API for base rates and settlement rules + a free LLM (e.g., Roy's existing
  Gemini API access) with the paper's MCP prompt template; MixMCP mixture alpha=0.7.
- Log model probability vs Polymarket price at fixed cutoffs for upcoming events; score Brier over
  4-8 weeks (~100-200 markets). If it can't beat the market's Brier on paper, the question is settled
  free. Even a small Brier win would NOT imply profit after spread+fee - that needs a separate
  simulated-trading test against real order books.

## Sources
- https://arxiv.org/html/2602.21229v2 (MixMCP paper, full text + PDF)
- https://parrot.markets/ , /methodology , /accuracy , /api-guide , /agents (fetched 2026-10-25)
- https://docs.polymarket.com/trading/fees
- https://gamma-api.polymarket.com/events/1242924 (live event/market data, fetched 2026-10-25 ~10:40 IST)
- https://polymarket-upload.s3.us-east-2.amazonaws.com/market_products/Mentions/Event+Mentions+Contract+DeFi.pdf
- https://www.npr.org/2026/08/13/nx-s1-5930689/cftc-probe-mention-markets-prediction-markets-kalshi
- https://www.lightningrod.ai/models , https://docs.lightningrod.ai/
- https://pickscribe.com/v/ePT6aMqk2Oo (Tyrael full interview transcript)
- https://www.youtube.com/watch?v=brAukxAt2Ls (Tyrael, Prediction Market Movers)
- https://www.polyresearchrobotics.com/strategies/speaker-idiolect-frequency-model (vendor strategy db)
- https://help.kalshi.com/en/articles/14026044 (Kalshi international availability: many countries, terms apply)
