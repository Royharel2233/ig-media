#!/bin/sh
# One scheduled cycle: snapshot, then rescore. Safe to re-run.
cd "$(dirname "$0")" && python3 collect.py && python3 score.py > results/last_score.txt 2>&1; tail -3 results/last_score.txt
