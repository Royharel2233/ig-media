"""Shared helpers. Public read-only sources only: Parrot (parrot.markets, CC BY 4.0) and Polymarket gamma API.
No keys, no accounts, no orders, no wallets."""
import json, time, urllib.request, urllib.error, urllib.parse, datetime as dt, os, re

UA = "mention-paper-prototype/0.1 (research, read-only, low rate)"
PARROT = "https://parrot.markets/api/v1"
GAMMA = "https://gamma-api.polymarket.com"
DATA = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
_last = {}
FAILS = []  # (url, reason) collected per process, logged by callers

def get_json(url, min_gap=0.6):
    host = urllib.parse.urlparse(url).netloc
    wait = min_gap - (time.time() - _last.get(host, 0))
    if wait > 0:
        time.sleep(wait)
    req = urllib.request.Request(url, headers={"User-Agent": UA, "Accept": "application/json"})
    for attempt in range(3):
        try:
            with urllib.request.urlopen(req, timeout=30) as r:
                _last[host] = time.time()
                return json.load(r)
        except urllib.error.HTTPError as e:
            _last[host] = time.time()
            if e.code == 429:
                time.sleep(10 * (attempt + 1)); continue
            if e.code == 404:
                FAILS.append((url, "404")); return None
            FAILS.append((url, f"http {e.code}")); return None
        except Exception as ex:
            time.sleep(3); last_ex = repr(ex)
    FAILS.append((url, "failed after retries"))
    return None

def now_utc():
    return dt.datetime.now(dt.timezone.utc)

def iso(t):
    return t.strftime("%Y-%m-%dT%H:%M:%SZ")

def parse_iso(s):
    return dt.datetime.fromisoformat(s.replace("Z", "+00:00"))

def norm(s):
    return re.sub(r"[^a-z0-9]+", " ", (s or "").lower()).strip()

def table(d):
    cols = d["cols"]
    return [dict(zip(cols, r)) for r in d["rows"]]

def f(x):
    try:
        return None if x is None else float(x)
    except Exception:
        return None
