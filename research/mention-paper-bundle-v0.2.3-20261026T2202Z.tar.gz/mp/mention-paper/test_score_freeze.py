"""Offline tests (no network): freeze cutoff, staleness, spread filter, prior-only stratum, null end, no-lookahead."""
import score, copy
END="2026-10-26T00:00:00Z"
def row(mid_, at, bid=None, ask=None, src="hist", end=END, p=0.40, m="M1"):
    return {"market_id":m,"event_slug":"e","event_end":end,"fetched_at":at,"bid":bid if bid is not None else mid_-.01,
            "ask":ask if ask is not None else mid_+.01,"last":mid_,"volume":100,"parrot_p":p,"parrot_p_src":src}
res={"M1":{"y":1,"closed_time":"2026-10-25 20:00:00+00"}}
A=row(.51,"2026-10-25T17:00:00Z"); B=row(.98,"2026-10-25T23:00:00Z")
r=score.score([A,B],res,cutoffs=(6,),max_stale=12)["by_cutoff"]["6"]
assert r["headline_excl_prior_only_p"]["metrics"]["market_mid"]["brier"]==0.2401, r  # A used, B not
assert r["headline_excl_prior_only_p"]["scored_markets"]==1
assert r["headline_excl_prior_only_p"]["scored_markets"]==1 and r["detail"][0]["hours_before_end"]==7.0
assert r["detail"][0]["resolved_early_yes_or_no"] is True  # closed 4h before end
# 24h cutoff: nothing before -> excluded, not scored
r=score.score([A,B],res,cutoffs=(24,))["by_cutoff"]["24"]
assert r["headline_excl_prior_only_p"]["scored_markets"]==0 and r["excluded"]["no_snapshot_before_cutoff"]==1
# stale: snapshot 20h before the 6h cutoff with max_stale 12 -> excluded
S=row(.5,"2026-10-24T22:00:00Z")
r=score.score([S],res,cutoffs=(6,),max_stale=12)["by_cutoff"]["6"]; assert r["excluded"]["freeze_snapshot_too_stale"]==1
# one-sided / wide book not a benchmark
r=score.score([dict(A,bid=None)],res,cutoffs=(6,))["by_cutoff"]["6"]; assert r["excluded"]["no_two_sided_book_or_wide_spread"]==1
r=score.score([dict(A,bid=.05,ask=.64)],res,cutoffs=(6,))["by_cutoff"]["6"]; assert r["excluded"]["no_two_sided_book_or_wide_spread"]==1
# prior-only p goes to its own stratum
r=score.score([dict(A,parrot_p_src="prior")],res,cutoffs=(6,))["by_cutoff"]["6"]
assert r["headline_excl_prior_only_p"]["scored_markets"]==0 and r["prior_only_p_stratum"]["scored_markets"]==1
# null event_end skipped, no crash
o=score.score([dict(A,event_end=None)],res,cutoffs=(6,)); assert o["skipped_null_end_rows"]==1
# no-lookahead: changing any snapshot taken after the cutoff, or adding one, never changes the scored result
base=score.score([A,B],res,cutoffs=(6,))["by_cutoff"]["6"]["headline_excl_prior_only_p"]
for later in (dict(B,bid=.2,ask=.3,parrot_p=.99), dict(B,at="x") and dict(B,fetched_at="2026-10-25T18:30:00Z")):
    assert score.score([A,later],res,cutoffs=(6,))["by_cutoff"]["6"]["headline_excl_prior_only_p"]==base
# blank / unknown p_src is its own stratum, not headline
r=score.score([dict(A,parrot_p_src=None)],res,cutoffs=(6,))["by_cutoff"]["6"]
assert r["headline_excl_prior_only_p"]["scored_markets"]==0 and r["unknown_src_p_stratum"]["scored_markets"]==1
# end moved between snapshots: excluded, never scored
r=score.score([A,dict(B,event_end="2026-10-25T19:05:00Z")],res,cutoffs=(6,))["by_cutoff"]["6"]
assert r["excluded"]["event_end_changed_between_snapshots"]==1 and r["headline_excl_prior_only_p"]["scored_markets"]==0
print("ok: all score freeze tests passed")
