import history
rows=[(f"2025-01-{d:02d}", "w%d"%(i%3), "e", (d*7+i)%2) for d in range(1,29) for i in range(4)]
base=history.evaluate(rows)
alt=[r if r[0]<"2025-01-20" else (r[0],r[1],r[2],1-r[3]) for r in rows]
a2=history.evaluate(alt)
# predictions for listings before 2025-01-20 must be identical when later outcomes are flipped
n=sum(1 for r in rows if r[0]<"2025-01-20")
k=sum(1 for r in rows if r[0]<"2025-01-20")-30 if False else None
same=[x for x,y in zip(base["word_sh"],a2["word_sh"])][:20]
assert base["word_sh"][:20]==a2["word_sh"][:20]
print("ok: early predictions unchanged by later outcomes")
