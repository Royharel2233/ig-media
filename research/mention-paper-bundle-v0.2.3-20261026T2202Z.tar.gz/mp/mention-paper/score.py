"""Prospective scoring. Per market and pre-declared cutoff c (hours before event_end): the forecast is the LAST snapshot
with fetched_at <= event_end - c, and only if it is not older than --max-stale hours before that cutoff. Rows with
null event_end are skipped. Markets whose event_end differs between snapshots (venue moved the end) are excluded and counted, because the cutoff would be defined against an unreliable end. All predictors are scored on the SAME markets.
Market benchmark requires a two-sided book with spread <= --max-spread (default 0.30); one-sided or wide books and
last-trade-only prices are NOT used as a market benchmark (counted as excluded).
Headline Parrot p requires p_src in hist/tx/blend. 'prior' (base rate, no word history) and blank/unknown p_src are
each their own stratum, never assumed to be good. max-spread 0.30 and max-stale 12h are arbitrary pre-registered pilot
choices, not optimized; sensitivity over a fixed grid is reported separately. Outcomes: gamma, umaResolutionStatus resolved with outcomePrices exactly 1/0 (voids excluded);
closed_time kept so early-YES markets (closed before event_end) are labelled. Blend 0.7*mid+0.3*parrot uses MixMCP's
weights but a base rate, NOT an LLM: it is not MixMCP. Paper trade: 1 share at best ask (YES) or 1-bid (NO),
taker fee 0.04*p*(1-p), best quote only, no depth/slippage: OPTIMISTIC, not evidence of executable profit.
Run: python3 score.py [--cutoffs 24 6] [--edge 0.10] [--max-stale 12] [--max-spread 0.30]"""
import glob, json, math, argparse, collections
from common import *

def load_snaps():
    rows = []
    for p in sorted(glob.glob(f"{DATA}/snapshots/*.jsonl")):
        rows += [r for r in (json.loads(l) for l in open(p) if l.strip()) if not (r.get("word") or "").startswith("-No Qualifying")]
    return rows

def fetch_outcomes(slugs):
    path = f"{DATA}/outcomes.json"
    cache = json.load(open(path)) if os.path.exists(path) else {}
    cache = {k: v for k, v in cache.items() if isinstance(v, dict)}  # drop legacy int format
    for s in slugs:
        d = get_json(f"{GAMMA}/events?slug={s}")
        if not d: continue
        for m in d[0]["markets"]:
            if m.get("closed") and m.get("umaResolutionStatus") == "resolved":
                try: pr = [float(x) for x in json.loads(m["outcomePrices"])]
                except Exception: continue
                y = 1 if pr == [1.0, 0.0] else 0 if pr == [0.0, 1.0] else None
                cache[m["id"]] = {"y": y, "closed_time": m.get("closedTime"), "event_slug": s}
    json.dump(cache, open(path, "w"))
    return cache

def book_mid(r, max_spread):
    b, a = r.get("bid"), r.get("ask")
    if b is None or a is None or a < b or a - b > max_spread: return None
    return (a + b) / 2

def fee(p): return 0.04 * p * (1 - p)

def metrics(pairs):
    n = len(pairs)
    if not n: return None
    e = 1e-3
    cl = lambda p: min(max(p, e), 1 - e)
    return {"n": n, "brier": round(sum((p - y) ** 2 for p, y in pairs) / n, 4),
            "logloss": round(-sum(y * math.log(cl(p)) + (1 - y) * math.log(1 - cl(p)) for p, y in pairs) / n, 4)}

def parse_ct(s):
    if not s: return None
    try: return dt.datetime.fromisoformat(s.replace(" ", "T").replace("+00", "+00:00"))
    except Exception: return None

def score(snaps, res, cutoffs=(24, 6), edge=0.10, max_stale=12, max_spread=0.30):
    by_m = collections.defaultdict(list)
    skipped_null_end = 0
    for r in snaps:
        if not r.get("event_end"): skipped_null_end += 1; continue
        by_m[r["market_id"]].append(r)
    out = {"n_snapshot_rows": len(snaps), "n_markets_seen": len(by_m), "skipped_null_end_rows": skipped_null_end,
           "n_resolved_with_snapshots": sum(1 for m in by_m if (res.get(m) or {}).get("y") in (0, 1)),
           "n_resolved_total_in_cache": sum(1 for v in res.values() if v.get("y") in (0, 1)),
           "params": {"cutoffs_h": list(cutoffs), "edge": edge, "max_stale_h": max_stale, "max_spread": max_spread}, "by_cutoff": {}}
    for c in cutoffs:
        ex = collections.Counter(); sets = {"headline": [], "prior_only": [], "unknown_src": []}; trades = []; detail = []
        for m, rows in by_m.items():
            o = res.get(m)
            if not o or o.get("y") not in (0, 1): continue
            y = o["y"]
            ends = {r["event_end"] for r in rows}
            if len(ends) > 1: ex["event_end_changed_between_snapshots"] += 1; continue  # end time is not reliable: never score
            end = parse_iso(rows[0]["event_end"]); lim = end - dt.timedelta(hours=c)
            ok = [r for r in rows if parse_iso(r["fetched_at"]) <= lim]
            if not ok: ex["no_snapshot_before_cutoff"] += 1; continue
            r = max(ok, key=lambda r: r["fetched_at"])
            stale_h = (lim - parse_iso(r["fetched_at"])).total_seconds() / 3600
            if stale_h > max_stale: ex["freeze_snapshot_too_stale"] += 1; continue
            mp = book_mid(r, max_spread)
            if mp is None: ex["no_two_sided_book_or_wide_spread"] += 1; continue
            pp = r.get("parrot_p")
            if pp is None: ex["no_parrot_p"] += 1; continue
            ct = parse_ct(o.get("closed_time"))
            early = bool(ct and ct < end - dt.timedelta(hours=1))
            src = r.get("parrot_p_src")
            stratum = "headline" if src in ("hist", "tx", "blend") else "prior_only" if src == "prior" else "unknown_src"  # unknown/blank provenance never assumed good
            sets[stratum].append((mp, pp, 0.7 * mp + 0.3 * pp, y))
            detail.append({"market_id": m, "stratum": stratum, "freeze_fetched_at": r["fetched_at"],
                           "hours_before_end": round((end - parse_iso(r["fetched_at"])).total_seconds() / 3600, 2),
                           "stale_vs_cutoff_h": round(stale_h, 2), "resolved_early_yes_or_no": early, "y": y})
            if stratum == "headline":
                model = 0.7 * mp + 0.3 * pp
                if model - r["ask"] >= edge: trades.append((r["ask"], y, r["volume"]))
                elif r["bid"] - model >= edge: trades.append((1 - r["bid"], 1 - y, r["volume"]))
        def block(rows):
            names = ["market_mid", "parrot_p", "blend_70_30_baserate"]
            return {"scored_markets": len(rows), "metrics": {n: metrics([(t[i], t[3]) for t in rows]) for i, n in enumerate(names)}}
        pnl = [(1 - px) - fee(px) if won else -px - fee(px) for px, won, _ in trades]
        out["by_cutoff"][str(c)] = {"headline_excl_prior_only_p": block(sets["headline"]),
            "prior_only_p_stratum": block(sets["prior_only"]), "unknown_src_p_stratum": block(sets["unknown_src"]), "excluded": dict(ex),
            "paper_trades_best_quote_OPTIMISTIC": {"n": len(trades), "pnl_per_share_total": round(sum(pnl), 3) if pnl else None},
            "detail": detail}
    return out

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--cutoffs", type=float, nargs="+", default=[24, 6])
    ap.add_argument("--edge", type=float, default=0.10)
    ap.add_argument("--max-stale", type=float, default=12)
    ap.add_argument("--max-spread", type=float, default=0.30)
    a = ap.parse_args()
    snaps = load_snaps()
    res = fetch_outcomes(sorted({r["event_slug"] for r in snaps}))
    rep = score(snaps, res, a.cutoffs, a.edge, a.max_stale, a.max_spread)
    # Sensitivity of the two arbitrary pilot filters. Fixed grid declared in advance; reported, never used to pick a setting.
    rep["sensitivity_fixed_grid"] = {f"stale{st}_spread{sp}": {k: v["headline_excl_prior_only_p"] for k, v in
        score(snaps, res, a.cutoffs, a.edge, st, sp)["by_cutoff"].items()} for st in (6, 12, 24) for sp in (0.15, 0.30, 0.50)}
    os.makedirs("results", exist_ok=True)
    json.dump(rep, open("results/prospective_report.json", "w"), indent=1)
    slim = dict(rep); slim["sensitivity_fixed_grid"] = "see results/prospective_report.json"; slim["by_cutoff"] = {k: {x: y for x, y in v.items() if x != "detail"} for k, v in rep["by_cutoff"].items()}
    print(json.dumps(slim, indent=1))
    if rep["n_resolved_with_snapshots"] < 100:
        print("\nWARNING: fewer than ~100 resolved markets with snapshots; differences are not distinguishable from luck.")

if __name__ == "__main__":
    main()
