"""HISTORICAL walk-forward evaluation (backtest). Clearly separate from the prospective log.
Data: Parrot settlement history per (entity, word): settled listings with date and YES/NO. NO market prices
exist in this data, so this CANNOT say anything about beating a market or about trading edge. It only asks:
does a base-rate predictor built from strictly EARLIER settled listings beat a constant rate?
No lookahead: for a listing dated D, only listings of the same entity with date < D feed the predictor
(same-day listings are never used for each other). Predictors:
  const   : expanding pooled YES rate of all earlier listings (all words, same entity)
  word_sh : (y_w + k*pool)/(n_w + k) from earlier listings of that word (k=4 shrinkage)
Run: python3 history.py [--entities donald-trump,...] ; caches API responses in data/history_cache."""
import argparse, collections, json, math, hashlib
from common import *

def cached(url):
    p = f"{DATA}/history_cache/{hashlib.md5(url.encode()).hexdigest()}.json"
    if os.path.exists(p): return json.load(open(p))
    d = get_json(url)
    if d is not None: json.dump(d, open(p, "w"))
    return d

def words_for(ent):
    ws = set()
    ev = cached(f"{PARROT}/upcoming?days=30&format=json")
    for r in table(ev):
        if r["ent"] == ent and r.get("ev"):
            b = cached(f"{PARROT}/brief?event={r['ev']}&limit=0&format=json")
            if b: ws |= {x["w"] for x in table(b)}
    return sorted(ws)

def listings(ent, w, venue="P"):
    d = cached(f"{PARROT}/history?entity={ent}&word={urllib.parse.quote(w)}&format=json")
    if not d: return []
    out = []
    for r in table(d):
        if r.get("res") in ("yes", "no") and r.get("v") == venue:
            out.append((r["date"], r["ev"], 1 if r["res"] == "yes" else 0))
    return out

def brier(ps): return sum((p - y) ** 2 for p, y in ps) / len(ps)

def evaluate(rows, k=4, min_prior_pool=30):
    rows = sorted(rows)  # (date, word, ev, y)
    by_date = collections.defaultdict(list)
    for r in rows: by_date[r[0]].append(r)
    wy = collections.defaultdict(lambda: [0, 0]); pool = [0, 0]
    sc = {"const": [], "word_sh": []}
    for d in sorted(by_date):
        for _, w, ev, y in by_date[d]:  # predict using state strictly before day d
            if pool[1] >= min_prior_pool:
                pc = (pool[0] + 1) / (pool[1] + 2)
                n_w, y_w = wy[w][1], wy[w][0]
                sc["const"].append((pc, y)); sc["word_sh"].append(((y_w + k * pc) / (n_w + k), y))
        for _, w, ev, y in by_date[d]:  # then reveal day d
            wy[w][0] += y; wy[w][1] += 1; pool[0] += y; pool[1] += 1
    return sc

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--entities", default="donald-trump")
    ap.add_argument("--max-words", type=int, default=400)
    ap.add_argument("--as-of", default=None, help="YYYY-MM-DD: only listings dated before this day (default: today UTC). Fixes the vintage for reproduction.")
    ap.add_argument("--out", default="results/historical_report.json")
    a = ap.parse_args()
    allrows = []
    for ent in a.entities.split(","):
        for w in words_for(ent)[:a.max_words]:
            for date, ev, y in listings(ent, w):
                allrows.append((date, f"{ent}|{w}", ev, y))
    today = a.as_of or now_utc().strftime('%Y-%m-%d')
    allrows = [r for r in allrows if r[0] < today]  # drop listings dated today/future (early-settled, window not ended)
    sc = evaluate(allrows)
    rep = {"as_of": today, "kind": "HISTORICAL walk-forward backtest, no market prices, no trading claim",
           "n_listings_total": len(allrows), "n_scored": len(sc["const"]),
           "date_range": [min(r[0] for r in allrows), max(r[0] for r in allrows)] if allrows else None,
           "brier": {k: round(brier(v), 4) for k, v in sc.items() if v},
           "caveats": ["Words are the CURRENTLY listed set (survivorship: words that were listed recently are over-represented).",
                       "Polymarket-venue listings only; Parrot 'res' strings as published.",
                       "Base rates only, no news. Market prices could not be used, so no comparison to the market."]}
    os.makedirs("results", exist_ok=True)
    json.dump(rep, open(a.out, "w"), indent=1)
    print(json.dumps(rep, indent=1))

if __name__ == "__main__":
    main()
