import React from 'react';
import { Callout, Caption, Closing, Facts, FileCard, Group, Header, NumberedList, Paragraph, Photos, Row, Rows, TextLink } from '@instinct/files';
import './style.css';
import books from './photos/books.png';

export function App() {
    return <FileCard>
        <Header
            title="איך למכור את שלושת הספרים"
            fact="25 באוקטובר 2026"
            intro="בדקתי מה מוציאים לאור של ספרי פאזלים דומים באמת עושים כדי למכור, לא רק מה שאומרים במדריכים. שורה תחתונה: אין ערוץ אחד שמוכח שמוכר, אבל יש דפוס ברור שחוזר אצל כולם, ויש כמה צעדים בחינם שמתאימים בדיוק לאילוצים שלך. לספר חג המולד יש חלון מכירות קצר, אז הוא ראשון בתור."
        />
        <Photos label="איור להמחשה" items={[{ src: books, alt: 'ערימת ספרי פאזלים על שולחן עם מתנה עטופה' }]} />
        <Caption>איור להמחשה בלבד, לא תמונה של הספרים עצמם.</Caption>

        <Group label="מה המתחרים שלך עושים בפועל" heading>
            <Paragraph>אלה מוציאים לאור אמיתיים בנישות של שלושת הספרים, ומה שרואים אצלם בפועל היום. שים לב: אף אחד מהם לא מפרסם כמה מכירות כל ערוץ מביא, אז אי אפשר לדעת מה הכי משתלם להם.</Paragraph>
            <Rows>
                <Row number={1} name="Blue Wave Press (ספרי פעילות לילדים, כולל חג המולד)" detail="המתחרה המוביל בספר חג המולד שלך. מוכר באמזון ובמקביל מפעיל חנות משלו ב־dylannapublishing.com עם כל הקטלוג." />
                <Row number={2} name="Bailey's Puzzles (קלקודוקו, מתחרה ישיר)" detail="אתר משלו עם 'מועדון פאזלים': נרשמים במייל ומקבלים פאזל חינמי כל שבוע. מהאתר קישורים לספרים באמזון וגם מכירת PDF ישירה." />
                <Row number={3} name="Puzzle Pines (גופן גדול לגמלאים)" detail="אתר עם חמישה פאזלים חינמיים בדפדפן. מוכר ספרים גם באמזון וגם ב־Etsy, וגם PDF להורדה מיידית. בונה סדרות נושאיות: לחתולים, לגננים, לחובבי היסטוריה." />
                <Row number={4} name="PuzzleFire Press (גמלאים)" detail="מחלק PDF חינמי של 20 עמודים תמורת הרשמה למייל. ממסגר את הספרים כמתנה: 'מתנה מושלמת לאמא או לסבתא'. סדרת כרכים לפי עונות השנה." />
                <Row number={5} name="Bold Puzzles ו־Front Porch Puzzle Press (גמלאים)" detail="אתרי פאזלים יומיים חינמיים בגופן גדול, בלי פרסומות. פונים במפורש גם למנהלי פעילות בבתי אבות, שקונים ספרים בכמויות לדיירים." />
                <Row number={6} name="KenKen (המותג המקביל לקלקודוקו)" detail="הערוץ המרכזי שלו: פאזלים חינמיים למורים ותוכנית כיתות. ככה ספרי החשבון שלו נכנסים לבתי ספר." />
            </Rows>
            <Callout title="מה המכנה המשותף" tone="neutral">כמעט כולם מפעילים אתר קטן משלהם עם פאזלים חינמיים שמוביל לאמזון, וחלקם גם רשימת מייל. זה הדפוס שחוזר, לא רשתות חברתיות. בבדיקת המתחרים מ־19 באוקטובר ראינו גם מתחרים שמפרסמים מודעות באמזון עצמו; היום אין לי גישה לאמזון לאמת שזה עדיין כך.</Callout>
        </Group>

        <Group label="מה זה אומר על שלושת הספרים שלך" heading>
            <Rows>
                <Row number={1} name="ספר חג המולד לילדים" detail="הכי דחוף: ספר חג מולד נמכר בעיקר לקראת החג, אז מה שעושים עכשיו שווה הכי הרבה. המסגרת הנכונה היא מתנה: סבתא קונה לנכד, לא הורה קונה לילד שלו. הפינים בפינטרסט כבר מכוונים לשם." />
                <Row number={2} name="ספר הגופן הגדול לגמלאים" detail="מכירות לאורך כל השנה. שני קהלים: גמלאים עצמם, וילדים בוגרים שקונים מתנה להורים. מה שמוכר אצל המתחרים: גופן גדול באמת גם בפתרונות, ספרים נושאיים (נוסטלגיה, טבע, חגים), וסדרות כרכים." />
                <Row number={3} name="ספר הקלקודוקו" detail="נישה קטנה בלי מוביל ברור. המתחרה הישיר Bailey's Puzzles בונה נוכחות דרך אתר פאזל שבועי חינמי. מתאים לספר שני ושלישי מאוחר יותר, לא למאמץ שיווקי נפרד עכשיו." />
            </Rows>
        </Group>

        <Group label="מה כן לעשות, בסדר עדיפות" heading>
            <NumberedList items={[
                'ניסוי: אתר קטן של Clear Mind Puzzles עם פאזל יומי חינמי לכל סוג ספר, וקישור לאמזון ליד כל אחד. זה הדפוס שחוזר אצל המתחרים, והקוד שמייצר את הספרים יכול לייצר את האתר. אבל זה ניסוי בלבד: דורש הפצה ותחזוקה שוטפת, ואין ערובה שימכור. אני בונה, אתה מאשר, ומודדים תוצאות.',
                'השלמת הכלים החינמיים של אמזון: דף Author Central לשם העט Walter Hayes ותוכן A+ Content (תמונות וטבלה בעמוד הספר). אתה מבצע ב־KDP כי זה בחשבון שלך, אני מכין את כל הטקסטים מראש. חד פעמי.',
                'פינטרסט: להחזיר את הפינים של שני הספרים החדשים עכשיו שהם חיים, ופינים של מתנה לחג המולד. ציפייה ריאלית: מו"לים ב־Reddit מדווחים על הרבה חשיפות אבל מעט קליקים ומכירות. זה בחינם, אז שווה, אבל לא לצפות לנס.',
                'ביקורות: ברויזיית תוכן עתידית של ספר, עמוד אחרון עם בקשה כנה לביקורת וקוד QR. מדיניות אמזון אוסרת ביקורות בתשלום, בתנאי, בהחלפה או ממשפחה וחברים. הבקשה הכנה היא הדרך המותרת היחידה.',
                'ערוץ סרטונים קצרים: ההצעה מ־20 באוקטובר (סרטון פאזל יומי ביוטיוב שורטס) עדיין על השולחן ומחכה להחלטתך. יש דיווח אנקדוטלי אחד ממו"ל ב־Reddit על מכירות מערוץ כזה, לא הוכחה. לא מתחיל בלי אישור שלך.',
            ]} />
        </Group>

        <Group label="איפה אפשר לפרסם: מה שמותר ומה שצריך בדיקה" heading>
            <Paragraph>שלושה ערוצים שמותרים בוודאות לפי הכללים שבדקתי מול המקורות, וליד אחד שההרשאה בו לא ידועה ודורש בדיקה לפני שמתחילים:</Paragraph>
            <Rows>
                <Row number={1} name="הכלים החינמיים של אמזון עצמה" detail="Author Central ותוכן A+ Content. שניהם רשמיים ומותרים לגמרי: אתה מבצע בחשבון ה־KDP שלך, אני מכין את הטקסטים." />
                <Row number={2} name="פינטרסט (החשבון הקיים clearmindpuzzles)" detail="פינים עם קישור לאמזון מותרים וכבר עובדים אצלנו. להחזיר את הפינים של שני הספרים החדשים עכשיו שהם חיים." />
                <Row number={3} name="פורום מנהלי הפעילות activitydirector.net" detail="פורום שבו מנהלי פעילות בבתי אבות חולקים רעיונות, וזה סוג הקהל שקונה בכמויות אצל המתחרים. אבל הרשאת הפרסום שם לא ידועה: לא מפורסמים כללי פרסום, ותוכן חינמי לא פטור אוטומטית. לפני כל פרסום, כולל פאזל חינמי, צריך לפנות למנהלי הפורום ולשאול. בנוסף, הפעילות שם איטית (הפוסט האחרון שראיתי מינואר 2025)." />
                <Row number={4} name="רדיט r/puzzles" detail="הכללים מתירים לפרסם פאזל שאתה יצרת עד פעם בשבוע, בלי קישור מסחרי. הפרופיל יכול לשאת את שם המותג. איטי אבל מותר ואמיתי." />
            </Rows>
        </Group>

        <Group label="מה פחות מתאים, ולמה" heading>
            <Rows>
                <Row number={1} name="קהילות Reddit" detail="r/sudoku אוסר במפורש פוסטים שמטרתם קידום (עדכון חוקים ממרץ 2026). r/puzzles מתיר פאזלים עצמיים רק בלי קישור מסחרי ועד אחד בשבוע. r/wordgames מתיר מדי פעם רק למי שמשתתף פעיל בקהילה. דורש זמן קבוע, לא מתאים לתקציב של עשר דקות ביום." />
                <Row number={2} name="קבוצות פייסבוק לקידום ספרים" detail="רובן סופרים שמוכרים לסופרים אחרים. קבוצות הביקורות המוקדמות (ARC) מיועדות לספרות ורומן, לא לספרי פאזלים בדפוס. לגמלאים יש קהל אמיתי בקבוצות של מנהלי פעילות, אבל פרסום שם דורש השתתפות ופנייה, ששניהם מחוץ לאילוצים שלך." />
                <Row number={3} name="Goodreads giveaways" detail="מבצע בתשלום, ועוד עלות עותקים ומשלוח לזוכים. בתגובות לדף הרשמי, מוציאים לאור עצמאיים מדווחים על תשואה חלשה מאוד (אחד קיבל ביקורת אחת ממבצע שלם)." />
                <Row number={4} name="מכירה בכמויות לבתי אבות" detail="ערוץ שעובד אצל מתחרים (Front Porch מוכר חבילות של 10 עד 25 עותקים), אבל דורש פנייה יזומה למנהלי פעילות. שומרים לרשימת 'אולי בעתיד'." />
                <Row number={5} name="מבצעי ניוזלטרים (Freebooksy וכדומה)" detail="מיועדים לספרים דיגיטליים בלבד. לא רלוונטי לספרים מודפסים." />
            </Rows>
        </Group>

        <Group label="אם תרצה לשלם, רק אם תחליט" heading>
            <Rows>
                <Row number={1} name="מודעות אמזון (Amazon Ads)" detail="הערוץ שבו ראינו מתחרים מפרסמים בבדיקה מ־19 באוקטובר. מדריכי התחום מזהירים לא לפרסם לפני שיש מכירות אורגניות שמוכיחות שהעמוד ממיר, וגם אז להתחיל קטן. ההחלטה והתשלום שלך בלבד." />
            </Rows>
        </Group>

        <Group label="מה לא ידוע ומה המגבלות" heading>
            <Facts items={[
                { label: 'תצוגת העמודים', value: 'אין לי כרגע גישה לאמזון, אז לא אימתתי את העמודים החיים. ההשקה עצמה מדווחת ממך, לא נבדקה על ידי.' },
                { label: 'שני הקישורים החדשים', value: 'שני ה־ASIN החדשים עוד לא שויכו בוודאות, איזה מהם ספר הגמלאים ואיזה ספר הקלקודוקו. הם חדשים מכדי להופיע בחיפוש.' },
                { label: 'הוכחת תשואה', value: 'אין הוכחה פומבית שאיזשהו ערוץ מוכר ספרים. ההמלצות מבוססות על מה שמתחרים עושים בפועל, על דיווחי קהילה, ועל האילוצים שלך.' },
            ]} />
        </Group>

        <Group label="מקורות עיקריים" heading>
            <Paragraph>
                אתרי המתחרים: <TextLink href="https://dylannapublishing.com/collections/blue-wave-press">Blue Wave Press</TextLink>, <TextLink href="https://baileyspuzzles.com/calcudoku-puzzle-books/">Bailey's Puzzles</TextLink>, <TextLink href="https://puzzlepines.com/">Puzzle Pines</TextLink>, <TextLink href="https://www.puzzlefirepress.com/">PuzzleFire Press</TextLink>, <TextLink href="https://boldpuzzles.com/">Bold Puzzles</TextLink>, <TextLink href="https://frontporchpuzzlepress.com/activity-directors/">Front Porch Puzzle Press</TextLink>, <TextLink href="https://www.kenkenpuzzle.com/teachers_classroom">KenKen למורים</TextLink>, <TextLink href="https://activitydirector.net/forum/forum/4-sharing-activities/">פורום מנהלי הפעילות</TextLink>.
                כללי קהילות: <TextLink href="https://www.reddit.com/r/sudoku/comments/1rsjzov/rule_update_no_more_appwebsite_announcement_posts/">עדכון החוקים של r/sudoku</TextLink>, <TextLink href="https://www.reddit.com/r/puzzles/comments/spp3m9/meta_can_i_post_my_own_puzzles_here_or_is_that/">דיון הכללים של r/puzzles</TextLink>, <TextLink href="https://www.reddit.com/r/wordgames/comments/1ob0x6h/meta_updated_rules_self_promotion_policy/">מדיניות r/wordgames</TextLink>.
                דיווחי קהילה: <TextLink href="https://www.reddit.com/r/KDP/comments/1vkdaek/has_anyone_actually_sold_kdp_books_through/">דיון על תוצאות פינטרסט ב־r/KDP</TextLink>.
                מדריכי תחום (טענות שלהם, לא מדידות): <TextLink href="https://www.kdpeasy.com/blog/amazon-ads-kdp-strategy">מדריך מודעות של KDPEasy</TextLink>.
                מדיניות ומחירונים: <TextLink href="https://smartkdp.com/blog/how-to-get-book-reviews-on-amazon">כללי הביקורות של אמזון</TextLink>, <TextLink href="https://www.goodreads.com/blog/show/1749-an-easy-way-to-promote-your-book-goodreads-giveaways">מחירון Goodreads giveaways</TextLink>.
            </Paragraph>
        </Group>

        <Closing>המחקר נערך ב־25 באוקטובר 2026. מחקר בלבד: לא בוצעה שום פעולה באתרים או בחשבונות.</Closing>
    </FileCard>;
}
