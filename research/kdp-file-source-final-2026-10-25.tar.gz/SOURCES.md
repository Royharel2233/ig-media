# Sources fetched live on 2026-10-25

## Competitor sites (observed promotion mechanics - cited in the File)
- https://www.dylannapublishing.com/collections/blue-wave-press - Blue Wave Press own storefront
- https://baileyspuzzles.com/calcudoku-puzzle-books/ - Puzzle Club email list, Amazon links, direct PDFs
- https://puzzlepines.com - free in-browser puzzles; sells on Amazon AND Etsy (Etsy kept as competitor observation only)
- https://puzzlefirepress.com - free 20-page PDF lead magnet, gift framing
- https://boldpuzzles.com - free daily large-print puzzles
- https://frontporchpuzzlepress.com/activity-directors/ - bulk pricing for activity directors
- https://www.kenkenpuzzle.com/teachers_classroom - classroom program
- https://activitydirector.net/forum/forum/4-sharing-activities/ - real forum; posting permission UNKNOWN (no published rules); newest visible post Jan 2025

## Community rules (cited)
- https://www.reddit.com/r/sudoku/comments/1rsjzov - March 2026 rule: no promo posts
- https://www.reddit.com/r/puzzles/comments/spp3m9 - own puzzles allowed if not money-linked, ~1/week
- https://www.reddit.com/r/wordgames/comments/1ob0x6h - occasional self-promo for active participants only
- https://www.reddit.com/r/KDP/comments/1vkdaek - Pinterest/TikTok anecdotes (anecdotes only, not evidence of sales)

## Policy / first-party (cited)
- https://smartkdp.com/blog/how-to-get-book-reviews-on-amazon - summary of Amazon review policy
- https://www.goodreads.com/blog/show/1749-an-easy-way-to-promote-your-book-goodreads-giveaways - official giveaway pricing page

## Vendor blogs fetched but NOT used as facts (claims-only, stats removed from the File)
- kdpeasy.com (seasonal windows post; ads strategy post - only the qualitative "start small / wait for organic sales" warning is cited)
- largeprintlab.com, rodbooks.com, bookbolt.io, bookpublishertools.com, bookquill.com, ragstoniches.com
