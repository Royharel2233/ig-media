import json, os, time, urllib.request, datetime as dt
os.makedirs('paper',exist_ok=True)
def get(url, tries=2, pause=8):
    for i in range(tries):
        try:
            req=urllib.request.Request(url,headers={'User-Agent':'research/1.0','Accept':'application/json'})
            return json.load(urllib.request.urlopen(req,timeout=20))
        except Exception as e:
            print('err',str(e)[:50],flush=True); time.sleep(pause)
    return None
state=json.load(open('paper/state.json')) if os.path.exists('paper/state.json') else {'positions':{},'closed':[],'seen_pools':[]}
now=dt.datetime.now(dt.timezone.utc)
sp=get('https://api.coingecko.com/api/v3/simple/price?ids=solana&vs_currencies=usd')
sol=(sp or {}).get('solana',{}).get('usd')
newpools=[]
for pg in range(1,5):
    d=get(f'https://api.geckoterminal.com/api/v2/networks/solana/new_pools?page={pg}',tries=1,pause=2)
    if not d or not d.get('data'): continue
    newpools+=d['data']
    time.sleep(3)
cands=[]
for p in newpools:
    a=p['attributes']
    dex=p['relationships']['dex']['data']['id']
    mint=p['relationships']['base_token']['data']['id'].replace('solana_','')
    if dex=='pumpswap' and mint.endswith('pump') and a['address'] not in state['seen_pools']:
        cands.append({'pool':a['address'],'mint':mint,'name':a.get('name'),'created':a.get('pool_created_at')})
seen_mints={p['mint'] for p in state['positions'].values()} | {c.get('mint','') for c in state['closed']}
cands=[c for c in cands if c['mint'] not in seen_mints]
dup=set()
cands=[c for c in cands if not (c['mint'] in dup or dup.add(c['mint']))]
for c in cands: state['seen_pools'].append(c['pool'])
print('graduation candidates this poll:',len(cands))
for c in cands:
    try:
        age_h=(now-dt.datetime.fromisoformat(c['created'].replace('Z','+00:00'))).total_seconds()/3600
    except Exception:
        age_h=99
    if age_h>12: print('skip old',c['name']); continue
    rc=get(f"https://api.rugcheck.xyz/v1/tokens/{c['mint']}/report",pause=12)
    time.sleep(1.5)
    ds=get(f"https://api.dexscreener.com/latest/dex/pairs/solana/{c['pool']}")
    pair=(ds.get('pairs') or [None])[0] if ds else None
    if not pair: print('no pair',c['name']); continue
    liq=(pair.get('liquidity') or {}).get('usd',0); fdv=pair.get('fdv',0); px=float(pair.get('priceUsd') or 0)
    rugged=False
    if rc and isinstance(rc,dict):
        rugged=any(t.get('rugged') for t in (rc.get('creatorTokens') or []) if isinstance(t,dict))
    if rugged: print('screen-out rug-history',c['name']); continue
    if liq<8000 or fdv<40000 or px<=0: print('screen-out liq/fdv',c['name'],liq,fdv); continue
    state['positions'][c['pool']]={'mint':c['mint'],'name':c['name'],'entry_px':px,'entry_t':now.isoformat(),
        'entry_liq':liq,'entry_fdv':fdv,'sol_entry':sol,'size':50.0,'remaining':1.0,'tp_done':False,
        'created':c['created'],'entry_px_eff':px*1.02*1.01}
    print('ENTER',c['name'],'@',px,'liq',liq,'fdv',fdv)
    json.dump(state,open('paper/state.json','w'))
addrs=list(state['positions'].keys())
cur={}
for i in range(0,len(addrs),30):
    d=get(f"https://api.dexscreener.com/latest/dex/pairs/solana/{','.join(addrs[i:i+30])}")
    if d:
        for pr in d.get('pairs') or []: cur[pr['pairAddress']]=pr
    time.sleep(1.5)
for pool,pos in list(state['positions'].items()):
    pr=cur.get(pool)
    if not pr: continue
    px=float(pr.get('priceUsd') or 0); liq=(pr.get('liquidity') or {}).get('usd',0)
    ret=px/pos['entry_px_eff']-1
    age_d=(now-dt.datetime.fromisoformat(pos['entry_t'])).total_seconds()/86400
    exit_frac=0; reason=None
    if liq<2000: exit_frac=1.0; reason='dead-liq'
    elif ret<=-0.50: exit_frac=1.0; reason='stop-50'
    elif age_d>=7: exit_frac=1.0; reason='time-7d'
    elif ret>=1.0 and not pos['tp_done']: exit_frac=0.5; reason='tp+100(50%)'
    if exit_frac>0:
        frac=min(exit_frac, pos['remaining'])
        eff_ret=ret-0.01-0.02
        state['closed'].append({'pool':pool,'mint':pos['mint'],'name':pos['name'],'reason':reason,'frac':frac,'ret_net':eff_ret,
            'entry_t':pos['entry_t'],'exit_t':now.isoformat(),'sol_ret':(sol/pos['sol_entry']-1) if (sol and pos.get('sol_entry')) else None,
            'sniper':pos.get('sniper')})
        pos['remaining']-=frac
        if reason and reason.startswith('tp'): pos['tp_done']=True
        print('EXIT',pos['name'],reason,f'{eff_ret*100:+.1f}%')
        if pos['remaining']<=0.001 or reason in ('dead-liq','stop-50','time-7d'):
            del state['positions'][pool]
json.dump(state,open('paper/state.json','w'))
try:
    from sniper_probe import probe
    for pool,pos in state['positions'].items():
        if 'sniper' in pos: continue
        try:
            age_h=(now-dt.datetime.fromisoformat(pos['entry_t'])).total_seconds()/3600
        except Exception: age_h=99
        if age_h<1: continue
        f=probe(pool,pos['created'],max_tx=25)
        if f and f.get('n_tx'):
            pos['sniper']={k:f[k] for k in ('n_tx','n_buys','n_sells','buy_vol_sol','bucket_sol','first60_share','unique_buyers','span_s') if k in f}
            pos['sniper']['top_buyers']=[w for w,_ in (f.get('top_buyers') or [])[:3]]
            pos['sniper']['first_buyers']=f.get('first_buyers')
            print('sniper-features',pos['name'],'f60',pos['sniper'].get('first60_share'))
except Exception as e:
    print('probe step err',str(e)[:60])
json.dump(state,open('paper/state.json','w'))
open('paper/log.jsonl','a').write(json.dumps({'t':now.isoformat(),'cands':len(cands),'open':len(state['positions']),'closed':len(state['closed'])})+'\n')
print(f"STATE: open {len(state['positions'])}, closed {len(state['closed'])}, seen_pools {len(state['seen_pools'])}")
