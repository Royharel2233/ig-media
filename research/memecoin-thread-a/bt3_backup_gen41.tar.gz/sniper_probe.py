import json, time, urllib.request, datetime as dt
def rpc(method, params, tries=2):
    body=json.dumps({"jsonrpc":"2.0","id":1,"method":method,"params":params}).encode()
    for i in range(tries):
        try:
            req=urllib.request.Request('https://api.mainnet-beta.solana.com',data=body,headers={'Content-Type':'application/json','User-Agent':'research/1.0'})
            r=json.load(urllib.request.urlopen(req,timeout=25))
            if 'result' in r: return r['result']
        except Exception as e:
            time.sleep(3)
    return None
def probe(pool, created_iso, max_tx=25):
    created=int(dt.datetime.fromisoformat(created_iso.replace('Z','+00:00')).timestamp())
    sigs=[]; before=None
    while len(sigs)<400:
        p=[pool,{'limit':100}]
        if before: p[1]['before']=before
        r=rpc('getSignaturesForAddress',p)
        if not r: break
        sigs+=r
        if len(r)<100 or (r[-1].get('blockTime') or 0)<created-3600: break
        before=r[-1]['signature']
        time.sleep(0.3)
    sigs=[s for s in sigs if (s.get('blockTime') or 0)>=created-60]
    sigs.sort(key=lambda s:s.get('blockTime') or 0)
    txs=[]
    for s in sigs[:max_tx]:
        t=rpc('getTransaction',[s['signature'],{'encoding':'jsonParsed','maxSupportedTransactionVersion':0}])
        if not t: continue
        meta=t.get('meta') or {}
        keys=t['transaction']['message']['accountKeys']
        fp=keys[0]['pubkey'] if isinstance(keys[0],dict) else keys[0]
        pre=meta.get('preBalances',[0])[0]; post=meta.get('postBalances',[0])[0]
        txs.append({'wallet':fp,'sol_delta':(post-pre)/1e9,'t':t.get('blockTime'),'dt':(t.get('blockTime') or created)-created})
        time.sleep(0.2)
    buys=[x for x in txs if x['sol_delta']<-0.001]
    sells=[x for x in txs if x['sol_delta']>0.001]
    def bvol(lo,hi): return sum(-x['sol_delta'] for x in buys if lo<=x['dt']<hi)
    bb={'0-10s':bvol(0,10),'10-60s':bvol(10,60),'1-5m':bvol(60,300),'5-60m':bvol(300,3600)}
    totbuy=sum(-x['sol_delta'] for x in buys)
    perwallet={}
    for x in buys: perwallet[x['wallet']]=perwallet.get(x['wallet'],0)-x['sol_delta']
    top=sorted(perwallet.items(),key=lambda kv:-kv[1])[:5]
    return {'pool':pool,'created':created,'n_tx':len(txs),'n_buys':len(buys),'n_sells':len(sells),
            'buy_vol_sol':totbuy,'bucket_sol':bb,'first60_share':(bb['0-10s']+bb['10-60s'])/totbuy if totbuy else None,
            'unique_buyers':len(perwallet),'top_buyers':top,
            'first_buyers':[x['wallet'] for x in buys[:15]],
            'span_s':(sigs[-1]['blockTime']-created) if sigs else None}
