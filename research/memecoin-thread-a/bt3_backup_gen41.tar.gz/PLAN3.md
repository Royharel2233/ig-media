PLAN3 rebuilt #7 23 Oct. Rule v1 paper tracker; see transcript. Backup+inline state after each state change.
