# Corrected accounting analysis (23 Oct 2026) - analysis layer, raw state.json/log.jsonl unchanged

All outcomes are SIMULATED from DexScreener poll-time quotes (~6h cadence). No trade was ever executed; nothing is execution-verified. Absence of execution verification is not evidence that positive marks would have lost.

## Tracker formula (exact)
entry_eff = quoted_entry_px * 1.02 * 1.01 = px * 1.0302 (2% slip + 1% fee, multiplicative, on entry notional)
net = (exit_px / entry_eff) - 1 - 0.01 - 0.02  (exit costs modeled as additive 3.0 points of return)
Q = exit_px/entry_px - 1 is the quoted price change. Denominators: USD prices of the same DexScreener pair, quoted at entry poll and exit poll.
Exact identity: net = Q - (1+Q)*0.02922 - 0.03  (entry cost = 2.922% of quoted proceeds factor; exit cost = flat 3.0 points)

## Known model defect
The additive 3-point exit cost does not shrink as proceeds go to zero, so net < -100% is arithmetically possible but economically impossible (proceeds cannot be negative). 12 of 24 rows are affected. A corrected multiplicative scenario applies exit costs to proceeds: net_mult = (1+Q)/1.0302 * 0.99 * 0.98 - 1, which bounds net at >= -100%. This is a SCENARIO with explicit assumptions, not an executable view.

## Per-row decomposition

| trade | exit label | Q quoted chg | entry cost | exit cost (model) | net logged | net mult scenario | flags |
|---|---|---|---|---|---|---|---|
| GTA VI / SOL | dead-liq | -99.5% | 0.02pt | 3.00pt | -102.5% | -99.5% | impossible negative proceeds under additive model; stale mark on drained pool (liq<$2k), not exitable |
| UNPLUG / SOL | stop-50 | -96.7% | 0.10pt | 3.00pt | -99.8% | -96.9% | threshold label; level crossed between 6h polls, never observed near -50% |
| Doomsday / SOL | dead-liq | -98.9% | 0.03pt | 3.00pt | -101.9% | -98.9% | impossible negative proceeds under additive model; stale mark on drained pool (liq<$2k), not exitable |
| MORBLE / SOL | stop-50 | -87.6% | 0.36pt | 3.00pt | -91.0% | -88.3% | threshold label; level crossed between 6h polls, never observed near -50% |
| Muskito / SOL | dead-liq | 40.9% | 4.13pt | 3.00pt | 33.8% | 32.7% | stale mark on drained pool (liq<$2k), not exitable |
| MUSK / SOL | dead-liq | 25.9% | 3.69pt | 3.00pt | 19.2% | 18.6% | stale mark on drained pool (liq<$2k), not exitable |
| GTA VI / SOL | stop-50 | -82.2% | 0.52pt | 3.00pt | -85.7% | -83.2% | threshold label; level crossed between 6h polls, never observed near -50% |
| OTTERHOLD / SOL | stop-50 | -95.3% | 0.14pt | 3.00pt | -98.4% | -95.5% | threshold label; level crossed between 6h polls, never observed near -50% |
| YOKAI / SOL | stop-50 | -99.3% | 0.02pt | 3.00pt | -102.3% | -99.3% | impossible negative proceeds under additive model; threshold label; level crossed between 6h polls, never observed near -50% |
| SOLYA / SOL | dead-liq | -98.9% | 0.03pt | 3.00pt | -101.9% | -98.9% | impossible negative proceeds under additive model; stale mark on drained pool (liq<$2k), not exitable |
| Fomo / SOL | dead-liq | -99.5% | 0.01pt | 3.00pt | -102.5% | -99.6% | impossible negative proceeds under additive model; stale mark on drained pool (liq<$2k), not exitable |
| WIPD / SOL | dead-liq | 3.4% | 3.03pt | 3.00pt | -2.6% | -2.6% | stale mark on drained pool (liq<$2k), not exitable |
| Pepchi / SOL | dead-liq | 29.8% | 3.81pt | 3.00pt | 23.0% | 22.2% | stale mark on drained pool (liq<$2k), not exitable |
| TESLA SI / SOL | dead-liq | -99.5% | 0.02pt | 3.00pt | -102.5% | -99.5% | impossible negative proceeds under additive model; stale mark on drained pool (liq<$2k), not exitable |
| swordlon / SOL | stop-50 | -96.3% | 0.11pt | 3.00pt | -99.4% | -96.5% | threshold label; level crossed between 6h polls, never observed near -50% |
| fomo#2 / SOL | dead-liq | -99.5% | 0.02pt | 3.00pt | -102.5% | -99.5% | impossible negative proceeds under additive model; stale mark on drained pool (liq<$2k), not exitable |
| JIHYCEO / SOL | dead-liq | 16.5% | 3.42pt | 3.00pt | 10.1% | 9.7% | stale mark on drained pool (liq<$2k), not exitable |
| MrBeast / SOL | dead-liq | -96.4% | 0.11pt | 3.00pt | -99.5% | -96.6% | stale mark on drained pool (liq<$2k), not exitable |
| Rockstar / SOL | dead-liq | -99.6% | 0.01pt | 3.00pt | -102.6% | -99.6% | impossible negative proceeds under additive model; stale mark on drained pool (liq<$2k), not exitable |
| JAMESON / SOL | stop-50 | -97.8% | 0.06pt | 3.00pt | -100.9% | -98.0% | impossible negative proceeds under additive model; threshold label; level crossed between 6h polls, never observed near -50% |
| MrBeast / SOL | dead-liq | -99.5% | 0.01pt | 3.00pt | -102.5% | -99.5% | impossible negative proceeds under additive model; stale mark on drained pool (liq<$2k), not exitable |
| kimchi / SOL | dead-liq | 2.3% | 3.00pt | 3.00pt | -3.7% | -3.6% | stale mark on drained pool (liq<$2k), not exitable |
| Martin / SOL | stop-50 | -97.6% | 0.07pt | 3.00pt | -100.7% | -97.7% | impossible negative proceeds under additive model; threshold label; level crossed between 6h polls, never observed near -50% |
| DAZE / SOL | stop-50 | -97.4% | 0.08pt | 3.00pt | -100.5% | -97.6% | impossible negative proceeds under additive model; threshold label; level crossed between 6h polls, never observed near -50% |

## Reading rules for milestone reports
- Report quoted-price P&L (as logged) and the multiplicative-cost scenario side by side, each labeled.
- Q <= -90% = near-total QUOTED loss, not proven full wipeout.
- All four positive rows (Muskito, MUSK, Pepchi, JIHYCEO) are stale marks on drained pools: unverified, not profits, not disproven either.
- WIPD and kimchi (small negatives, dead-liq) are likewise unverifiable stale marks.
