# Mention-market paper forecasting prototype (paper only)

Local, free, read-only. Python 3 standard library only. No trades, wallets, keys, paid APIs or accounts.
Sources: Parrot (https://parrot.markets, free API, CC BY 4.0, credit parrot.markets) and Polymarket's public gamma API.
Not advice. Parrot says its probabilities are base rates, not forecasts, and operators trade these markets.

## Two separate things (do not mix them)
1. HISTORICAL backtest (`history.py`): walk-forward on Parrot settlement history. Each listing is predicted only from
   strictly earlier-dated listings. There are NO market prices in this data, so it can only show whether a base rate
   beats a constant. It says nothing about beating the market or trading edge. Word set is the currently listed set
   (survivorship bias). `test_nolookahead.py` checks that later outcomes cannot change earlier predictions.
2. PROSPECTIVE log (`collect.py` + `score.py`): snapshots taken in real time, append-only, open markets only,
   each row stamped fetched_at. Scoring freezes the forecast at the last snapshot at or before a pre-declared cutoff
   (default 24h and 6h before the event end) and scores all predictors on the same markets. This is the only part
   that can compare to the market, and it needs ~100+ resolved markets (weeks) before the numbers mean anything.

## Predictors
market mid; Parrot p (base rate); blend 0.7*mid + 0.3*Parrot p. The blend uses MixMCP's weights but a base rate instead
of an LLM, so it is NOT MixMCP. The LLM layer is not built: no free hosted model quota is verified, and a local model has not been tested. A `model_p` field can be added to
snapshots later if one proves feasible.

## Paper-trade readout
One share at the quoted ask (or NO at 1-bid) when the blend differs from the price by >= 10c, held to resolution,
taker fee 0.04*p*(1-p). Ignores depth beyond the best quote, so it is optimistic. Brier/log-loss gaps cannot be
converted into cents; only this readout approximates costs, and tiny n is noise.

## Known limits
- Weekly/monthly markets often resolve YES early; a snapshot after that point is excluded because closed markets are
  never recorded. Open-but-already-decided words still appear (price near 1) and can flatter the market predictor.
- Gamma bid/ask can be one-sided or 3-50c wide; midpoint of a wide book is a weak price.
- Word matching Parrot<->Polymarket is by normalized title; unmatched rows have no Parrot p and are not scored.
- Run `./run_wake.sh` every ~6h; scheduled by the owning task agent. Be gentle: ~0.6s gap between calls.

## v0.2 corrections after independent QA
- Snapshots are write-once generation files (data/snapshots/<UTC>.jsonl); data/logs/collect_log.jsonl records per run: events
  listed/skipped, null end, Parrot fetch failures, Parrot match coverage, unmatched words, p_src mix, API failures.
- Freeze semantics: last snapshot <= end - cutoff, rejected if older than max-stale (12h) before the cutoff; per-market
  hours_before_end and early-resolution flag in results/prospective_report.json detail.
- Market benchmark needs a two-sided book with spread <= 0.30; last-trade-only or one-sided books are excluded and counted.
- Parrot p with p_src 'prior' (no word history) is a separate stratum, not in the headline.
- Markets that closed before our first look (early YES) are never captured; the outcomes cache can hold resolved markets
  with no snapshot. Only 'n_resolved_with_snapshots' counts for prospective scoring.
- Tests: test_score_freeze.py (offline), test_nolookahead.py, history.py reproducibility from data/history_cache.
- Durable restore: unpack the latest archive in the repo, then rerun; never overwrite snapshot generations.

## v0.2.1
- Headline requires p_src in hist/tx/blend; 'prior' and blank/unknown p_src are separate strata (41/175 rows had blank p_src with a p value; provenance not assumed).
- max-spread 0.30 and max-stale 12h are arbitrary pre-registered pilot choices, not optimized. results/prospective_report.json carries a fixed-grid sensitivity block (stale 6/12/24h x spread 0.15/0.30/0.50) for reporting only.
- Status: tested collection prototype; no forecasting edge is validated.

## v0.2.2
- score.py excludes markets whose event_end changed between snapshots (venue moved the end, e.g. the Michigan rally event moved from 2026-10-26T19:05Z to 2026-10-25T19:05Z); collect.py logs end changes. An earlier interim peek that scored these markets was invalid and is retracted.
